﻿// Controllers/NotificationsController.cs
using Microsoft.AspNetCore.Mvc;
using ProjectandManagementBackEnd.Models.DTOs;

[ApiController]
[Route("api/[controller]")]
public class NotificationsController : ControllerBase
{
    private readonly NotificationService _notificationService;

    public NotificationsController(NotificationService notificationService)
    {
        _notificationService = notificationService;
    }

    // GET: api/notifications?userId=1
    [HttpGet]
    public async Task<IActionResult> GetNotifications(int userId)
    {
        var notifications = await _notificationService.GetUserNotifications(userId);
        return Ok(notifications);
    }

    // POST: api/notifications
    [HttpPost]
    public async Task<IActionResult> CreateNotification(
        [FromBody] CreateNotificationRequest request)
    {
        await _notificationService.CreateNotification(
            request.UserId,
            request.CreatedBy,
            request.Message);

        return Ok();
    }

    // POST: api/notifications/5/read
    [HttpPost("{id}/read")]
    public async Task<IActionResult> MarkAsRead(int id)
    {
        await _notificationService.MarkAsRead(id);
        return NoContent();
    }
    // GET: api/notifications/sent?managerId=2
    [HttpGet("sent")]
    public async Task<IActionResult> GetSentNotifications(int managerId)
    {
        var notifications = await _notificationService.GetNotificationsSentByManager(managerId);
        return Ok(notifications);
    }

    [HttpGet("count")]
    public ActionResult<int> GetCount()
    {
        var unread = _notificationService.GetUnreadCount();
        return Ok(unread);
    }
}

