﻿//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using ProjectandManagementBackEnd.DAI;
//using ProjectandManagementBackEnd.Models;
//using ProjectandManagementBackEnd.Models.DTOs;
//using System.Security.Claims;

//namespace ProjectandManagementBackEnd.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    [AllowAnonymous]
//    public class TeamsController : ControllerBase
//    {
//        private readonly ApplicationDbContext _context;
//        private readonly ILogger<TeamsController> _logger;

//        public TeamsController(ApplicationDbContext context, ILogger<TeamsController> logger)
//        {
//            _context = context;
//            _logger = logger;
//        }

//        private int GetCurrentManagerId()
//        {
//            if (User?.Identity?.IsAuthenticated != true)
//            {
//                throw new UnauthorizedAccessException("User is not authenticated");
//            }

//            var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
//            if (string.IsNullOrEmpty(userIdClaim) || !int.TryParse(userIdClaim, out var userId))
//            {
//                throw new UnauthorizedAccessException("Invalid user ID in token");
//            }

//            if (!User.IsInRole("Manager"))
//            {
//                throw new UnauthorizedAccessException("User is not a manager");
//            }

//            return userId;
//        }

//        // GET: api/teams
//        [HttpGet]
//        [ProducesResponseType(typeof(IEnumerable<TeamDto>), StatusCodes.Status200OK)]
//        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
//        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
//        public async Task<ActionResult<IEnumerable<TeamDto>>> GetTeams()
//        {
//            try
//            {
//                var managerId = GetCurrentManagerId();

//                var teams = await _context.Teams
//                    .Where(t => t.ManagerId == managerId)
//                    .Select(t => new TeamDto
//                    {
//                        Id = t.Id,
//                        Name = t.Name,
//                        Description = t.Description,
//                        CreatedDate = t.CreatedDate,
//                        MemberCount = t.Members.Count
//                    })
//                    .ToListAsync();

//                return Ok(teams);
//            }
//            catch (UnauthorizedAccessException ex)
//            {
//                return Unauthorized(new { Message = ex.Message });
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, "Error retrieving teams");
//                return StatusCode(500, new
//                {
//                    StatusCode = 500,
//                    Message = "Error retrieving teams",
//                    DetailedError = ex.Message
//                });
//            }
//        }

//        // GET: api/teams/5
//        [HttpGet("{id}")]
//        [ProducesResponseType(typeof(TeamDetailDto), StatusCodes.Status200OK)]
//        [ProducesResponseType(StatusCodes.Status404NotFound)]
//        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
//        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
//        public async Task<ActionResult<TeamDetailDto>> GetTeam(int id)
//        {
//            try
//            {
//                var managerId = GetCurrentManagerId();

//                var team = await _context.Teams
//                    .Include(t => t.Members)
//                    .ThenInclude(m => m.User)
//                    .FirstOrDefaultAsync(t => t.Id == id && t.ManagerId == managerId);

//                if (team == null)
//                {
//                    return NotFound(new { Message = "Team not found" });
//                }

//                var result = new TeamDetailDto
//                {
//                    Id = team.Id,
//                    Name = team.Name,
//                    Description = team.Description,
//                    CreatedDate = team.CreatedDate,
//                    Members = team.Members.Select(m => new TeamMemberDto
//                    {
//                        UserId = m.UserId,
//                        Name = m.User.Name,
//                        Email = m.User.Email,
//                        Role = m.Role,
//                        JoinedDate = m.JoinedDate
//                    }).ToList()
//                };

//                return Ok(result);
//            }
//            catch (UnauthorizedAccessException ex)
//            {
//                return Unauthorized(new { Message = ex.Message });
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, $"Error retrieving team with ID {id}");
//                return StatusCode(500, new
//                {
//                    StatusCode = 500,
//                    Message = "Error retrieving team",
//                    DetailedError = ex.Message
//                });
//            }
//        }

//        // POST: api/teams
//        [HttpPost]
//        [ProducesResponseType(typeof(TeamDto), StatusCodes.Status201Created)]
//        [ProducesResponseType(StatusCodes.Status400BadRequest)]
//        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
//        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
//        public async Task<ActionResult<TeamDto>> CreateTeam([FromBody] CreateTeamDto createTeamDto)
//        {
//            if (!ModelState.IsValid)
//            {
//                return BadRequest(new
//                {
//                    Message = "Validation failed",
//                    Errors = ModelState.Values
//                        .SelectMany(v => v.Errors)
//                        .Select(e => e.ErrorMessage)
//                });
//            }

//            try
//            {
//                var managerId = GetCurrentManagerId();

//                var team = new Team
//                {
//                    Name = createTeamDto.Name,
//                    Description = createTeamDto.Description,
//                    ManagerId = managerId,
//                    CreatedDate = DateTime.UtcNow
//                };

//                _context.Teams.Add(team);
//                await _context.SaveChangesAsync();

//                var result = new TeamDto
//                {
//                    Id = team.Id,
//                    Name = team.Name,
//                    Description = team.Description,
//                    CreatedDate = team.CreatedDate,
//                    MemberCount = 0
//                };

//                return CreatedAtAction(nameof(GetTeam), new { id = team.Id }, result);
//            }
//            catch (UnauthorizedAccessException ex)
//            {
//                return Unauthorized(new { Message = ex.Message });
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, "Error creating team");
//                return StatusCode(500, new
//                {
//                    StatusCode = 500,
//                    Message = "Error creating team",
//                    DetailedError = ex.Message
//                });
//            }
//        }

//        // POST: api/teams/5/members
//        [HttpPost("{teamId}/members")]
//        [ProducesResponseType(StatusCodes.Status204NoContent)]
//        [ProducesResponseType(StatusCodes.Status400BadRequest)]
//        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
//        [ProducesResponseType(StatusCodes.Status404NotFound)]
//        [ProducesResponseType(StatusCodes.Status409Conflict)]
//        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
//        public async Task<IActionResult> AddTeamMember(int teamId, [FromBody] AddMemberDto addMemberDto)
//        {
//            if (!ModelState.IsValid)
//            {
//                return BadRequest(new
//                {
//                    Message = "Validation failed",
//                    Errors = ModelState.Values
//                        .SelectMany(v => v.Errors)
//                        .Select(e => e.ErrorMessage)
//                });
//            }

//            try
//            {
//                var managerId = GetCurrentManagerId();

//                var team = await _context.Teams
//                    .FirstOrDefaultAsync(t => t.Id == teamId && t.ManagerId == managerId);

//                if (team == null)
//                {
//                    return NotFound(new { Message = "Team not found or you don't have permission" });
//                }

//                var user = await _context.Users.FindAsync(addMemberDto.UserId);
//                if (user == null)
//                {
//                    return BadRequest(new { Message = "User not found" });
//                }

//                var existingMember = await _context.TeamMembers
//                    .FirstOrDefaultAsync(m => m.TeamId == teamId && m.UserId == addMemberDto.UserId);

//                if (existingMember != null)
//                {
//                    return Conflict(new { Message = "User is already in this team" });
//                }

//                var teamMember = new TeamMember
//                {
//                    TeamId = teamId,
//                    UserId = addMemberDto.UserId,
//                    Role = addMemberDto.Role ?? "Member",
//                    JoinedDate = DateTime.UtcNow
//                };

//                _context.TeamMembers.Add(teamMember);
//                await _context.SaveChangesAsync();

//                return NoContent();
//            }
//            catch (UnauthorizedAccessException ex)
//            {
//                return Unauthorized(new { Message = ex.Message });
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, $"Error adding member to team {teamId}");
//                return StatusCode(500, new
//                {
//                    StatusCode = 500,
//                    Message = "Error adding team member",
//                    DetailedError = ex.Message
//                });
//            }
//        }

//        // DELETE: api/teams/5/members/5
//        [HttpDelete("{teamId}/members/{userId}")]
//        [ProducesResponseType(StatusCodes.Status204NoContent)]
//        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
//        [ProducesResponseType(StatusCodes.Status404NotFound)]
//        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
//        public async Task<IActionResult> RemoveTeamMember(int teamId, int userId)
//        {
//            try
//            {
//                var managerId = GetCurrentManagerId();

//                var team = await _context.Teams
//                    .FirstOrDefaultAsync(t => t.Id == teamId && t.ManagerId == managerId);

//                if (team == null)
//                {
//                    return NotFound(new { Message = "Team not found or you don't have permission" });
//                }

//                var teamMember = await _context.TeamMembers
//                    .FirstOrDefaultAsync(m => m.TeamId == teamId && m.UserId == userId);

//                if (teamMember == null)
//                {
//                    return NotFound(new { Message = "Member not found in this team" });
//                }

//                _context.TeamMembers.Remove(teamMember);
//                await _context.SaveChangesAsync();

//                return NoContent();
//            }
//            catch (UnauthorizedAccessException ex)
//            {
//                return Unauthorized(new { Message = ex.Message });
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, $"Error removing member {userId} from team {teamId}");
//                return StatusCode(500, new
//                {
//                    StatusCode = 500,
//                    Message = "Error removing team member",
//                    DetailedError = ex.Message
//                });
//            }
//        }

//        // DELETE: api/teams/5
//        [HttpDelete("{id}")]
//        [ProducesResponseType(StatusCodes.Status204NoContent)]
//        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
//        [ProducesResponseType(StatusCodes.Status404NotFound)]
//        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
//        public async Task<IActionResult> DeleteTeam(int id)
//        {
//            try
//            {
//                var managerId = GetCurrentManagerId();

//                var team = await _context.Teams
//                    .FirstOrDefaultAsync(t => t.Id == id && t.ManagerId == managerId);

//                if (team == null)
//                {
//                    return NotFound(new { Message = "Team not found" });
//                }

//                _context.Teams.Remove(team);
//                await _context.SaveChangesAsync();

//                return NoContent();
//            }
//            catch (UnauthorizedAccessException ex)
//            {
//                return Unauthorized(new { Message = ex.Message });
//            }
//            catch (Exception ex)
//            {
//                _logger.LogError(ex, $"Error deleting team {id}");
//                return StatusCode(500, new
//                {
//                    StatusCode = 500,
//                    Message = "Error deleting team",
//                    DetailedError = ex.Message
//                });
//            }
//        }
//    }
//}
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MySqlConnector;
using ProjectandManagementBackEnd.DAI;
using ProjectandManagementBackEnd.Models;
using ProjectandManagementBackEnd.Models.DTOs;

[ApiController]
[Route("api/[controller]")]
public class TeamsController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public TeamsController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public async Task<IActionResult> CreateTeam([FromBody] TeamCreateDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Name))
            return BadRequest("Team name is required.");

        var team = new Team { Name = dto.Name };
        _context.Teams.Add(team);
        await _context.SaveChangesAsync();

        return Ok(team);
    }
    [HttpPost("add-member")]
    public async Task<IActionResult> AddMember([FromBody] AddMemberDto dto)
    {
        if (!_context.Teams.Any(t => t.Id == dto.TeamId))
            return NotFound("Team not found");

        if (!_context.Users.Any(u => u.Id == dto.UserId))
            return NotFound("User not found");

        var member = new TeamMember
        {
            TeamId = dto.TeamId,
            UserId = dto.UserId
        };

        _context.TeamMembers.Add(member);
        await _context.SaveChangesAsync();

        return Ok(new { Message = "Member added successfully" });
    }
    [HttpGet]
    public async Task<IActionResult> GetTeams()
    {
        var teams = await _context.Teams
            .Include(t => t.Members)
            .Select(t => new
            {
                t.Id,
                t.Name,
                Members = t.Members.Select(m => new
                {
                    m.UserId
                })
            })
            .ToListAsync();

        return Ok(teams);
    }


}