﻿using Microsoft.EntityFrameworkCore;
using ProjectandManagementBackEnd.Models;

namespace ProjectandManagementBackEnd.DAI;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Users> Users { get; set; }
    public DbSet<Notification> Notifications { get; set; }
    public DbSet<Team> Teams { get; set; }
    public DbSet<TeamMember> TeamMembers { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Notification>(entity =>
        {
            // Configure relationships
            entity.HasOne<Users>()
                  .WithMany()
                  .HasForeignKey(n => n.UserId)
                  .HasPrincipalKey(u => (long)u.Id)
                  .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne<Users>()
                  .WithMany()
                  .HasForeignKey(n => n.CreatedBy)
                   .HasPrincipalKey(u => (long)u.Id)
                  .OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<TeamMember>()
                .HasKey(tm => new { tm.TeamId, tm.UserId });

            modelBuilder.Entity<TeamMember>()
                .HasOne(tm => tm.Team)
                .WithMany(t => t.Members)
                .HasForeignKey(tm => tm.TeamId);

            modelBuilder.Entity<TeamMember>()
                .HasOne(tm => tm.User)
                .WithMany(u => u.Teams)
                .HasForeignKey(tm => tm.UserId);

            base.OnModelCreating(modelBuilder);
            // Column configurations
            entity.Property(n => n.CreatedBy)
                  .IsRequired();

            entity.Property(n => n.CreatedAt)
                  .HasDefaultValueSql("CURRENT_TIMESTAMP");
           

        });
    }
}