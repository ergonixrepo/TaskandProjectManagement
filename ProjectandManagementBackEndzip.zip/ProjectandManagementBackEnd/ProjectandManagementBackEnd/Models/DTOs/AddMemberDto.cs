﻿using System.ComponentModel.DataAnnotations;

namespace ProjectandManagementBackEnd.Models.DTOs
{
    public class AddMemberDto
    {
       
            [Required]
            public int TeamId { get; set; }

            [Required]
            public int UserId { get; set; }
       

    }
}
