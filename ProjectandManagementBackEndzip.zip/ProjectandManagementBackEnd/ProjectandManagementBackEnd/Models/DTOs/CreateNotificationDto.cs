﻿using System.ComponentModel.DataAnnotations;

namespace ProjectandManagementBackEnd.Models.DTOs
{
    public class CreateNotificationDto
    {
        [Required]
        public int UserId { get; set; }  // Recipient

        

        [Required]
        public string Message { get; set; }
    }
}
