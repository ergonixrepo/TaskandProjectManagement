﻿namespace ProjectandManagementBackEnd.Models.DTOs
{
    public class CreateNotificationRequest
    {

        public int UserId { get; set; }
        public int CreatedBy { get; set; }
       
        public string Message { get; set; }
    }
}
