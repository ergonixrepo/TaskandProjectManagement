﻿namespace ProjectandManagementBackEnd.Models.DTOS
{
    public class RegisterDto
    {
        public string Name { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string Role { get; set; } = "Employee";
        public int no_of_years_experience { get; set; }
        public string gender { get; set; } = null!;
        public string job_designation { get; set; } = null!;
        public long phonenumber { get; set; }
    }
}
