﻿using System.ComponentModel.DataAnnotations;

namespace ProjectandManagementBackEnd.Models.DTOs
{
    public class TeamCreateDto
    {

        [Required]
        public string Name { get; set; }
      
    }
}
