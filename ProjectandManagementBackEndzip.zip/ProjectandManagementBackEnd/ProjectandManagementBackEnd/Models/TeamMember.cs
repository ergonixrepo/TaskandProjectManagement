﻿namespace ProjectandManagementBackEnd.Models
{
    public class TeamMember
    {
        public int TeamId { get; set; }
        public Team Team { get; set; }

        public int UserId { get; set; }
        public Users User { get; set; }
    }
}
