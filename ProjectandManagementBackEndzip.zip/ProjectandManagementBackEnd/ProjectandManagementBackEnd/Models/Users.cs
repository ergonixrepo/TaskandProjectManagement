﻿using System.ComponentModel.DataAnnotations;

namespace ProjectandManagementBackEnd.Models
{
    public class Users
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = null!;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = null!;

        [Required]
        public string Password { get; set; }

        [Required]
        public string Role { get; set; } = "Employee";
        public int no_of_years_experience { get; set; }
        public string gender { get; set; } = null!;
        public string job_designation { get; set; } = null!;
        public long phonenumber { get; set; }
        public ICollection<TeamMember> Teams { get; set; } = new List<TeamMember>();
    }
}
