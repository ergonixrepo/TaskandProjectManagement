﻿
//using Microsoft.AspNetCore.Authentication.JwtBearer;
//using Microsoft.AspNetCore.Diagnostics;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.IdentityModel.Tokens;
//using Microsoft.OpenApi.Models;
//using ProjectandManagementBackEnd.DAI;
//using ProjectandManagementBackEnd.Models;
//using ProjectandManagementBackEnd.Services;
//using System.Text;

//namespace ProjectandManagementBackEnd
//{
//    public class Program
//    {
//        public static void Main(string[] args)
//        {
//            var builder = WebApplication.CreateBuilder(args);


//            // Add DbContext
//            builder.Services.AddDbContext<ApplicationDbContext>(options =>
//     options.UseMySql(
//         builder.Configuration.GetConnectionString("DefaultConnection"),
//         new MySqlServerVersion(new Version(8, 0, 33)),
//         mysqlOptions =>
//         {
//             mysqlOptions.EnableRetryOnFailure(
//                 maxRetryCount: 5,
//                 maxRetryDelay: TimeSpan.FromSeconds(30),
//                 errorNumbersToAdd: null);
//         }
//     )
// );

//            // Add JWT Authentication
//            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
//                .AddJwtBearer(options =>
//                {
//                options.TokenValidationParameters = new TokenValidationParameters
//                {
//                    ValidateIssuer = true,
//                    ValidateAudience = true,
//                    ValidateLifetime = true, // Added
//                    ValidateIssuerSigningKey = true,
//                    ClockSkew = TimeSpan.Zero, // Strict token expiration
//                    ValidIssuer = builder.Configuration["Jwt:Issuer"],
//                    ValidAudience = builder.Configuration["Jwt:Audience"],
//                    IssuerSigningKey = new SymmetricSecurityKey(
//                        Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
//                };

//                // For WebSockets/SignalR
//                options.Events = new JwtBearerEvents
//                {
//                    OnMessageReceived = context =>
//                    {
//                        var accessToken = context.Request.Query["access_token"];
//                        if (!string.IsNullOrEmpty(accessToken))
//                        {
//                            context.Token = accessToken;
//                        }
//                        return Task.CompletedTask;
//                    }
//                };
//            });
//            // Add EmailSender
//            builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("EmailSettings"));
//            builder.Services.AddTransient<IEmailSender, EmailSender>();


//            // Add services to the container.

//            builder.Services.AddControllers();
//            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
//            builder.Services.AddEndpointsApiExplorer();
//            builder.Services.AddSwaggerGen(c =>
//            {
//                c.SwaggerDoc("v1", new OpenApiInfo { Title = "API", Version = "v1" });

//                var securityScheme = new OpenApiSecurityScheme
//                {
//                    Name = "JWT Authentication",
//                    Description = "Enter JWT Bearer token",
//                    In = ParameterLocation.Header,
//                    Type = SecuritySchemeType.Http,
//                    Scheme = "bearer",
//                    BearerFormat = "JWT",
//                    Reference = new OpenApiReference
//                    {
//                        Id = JwtBearerDefaults.AuthenticationScheme,
//                        Type = ReferenceType.SecurityScheme
//                    }
//                };

//                c.AddSecurityDefinition(securityScheme.Reference.Id, securityScheme);
//                c.AddSecurityRequirement(new OpenApiSecurityRequirement
//    {
//        { securityScheme, Array.Empty<string>() }
//    });
//            });

//            //builder.Services.AddSwaggerGen();
//            // Add CORS BEFORE building the app:
//            //builder.Services.AddCors(options =>
//            //{
//            //    options.AddPolicy("AllowReactApp",
//            //        policy =>
//            //        {
//            //            policy.WithOrigins("http://localhost:5173","http://localhost:5173")
//            //                  .AllowAnyHeader()
//            //                  .AllowAnyMethod()
//            //                 .AllowCredentials();
//            //        });
//            //});
//            var app = builder.Build();
//            //app.UseCors("AllowReactApp");
//            // Add CORS policy
//            builder.Services.AddCors(options =>
//            {
//                options.AddPolicy("ReactFrontend", builder =>
//                {
//                    builder.WithOrigins("http://localhost:5173", "https://localhost:5173")
//                           .AllowAnyHeader()
//                           .AllowAnyMethod()
//                           .AllowCredentials(); // Needed for cookies/JWT
//                });
//            });

//            // Then AFTER builder.Build():
//            app.UseHttpsRedirection();
//            app.UseRouting();

//            app.UseCors("ReactFrontend");
//            // Configure the HTTP request pipeline.
//            if (app.Environment.IsDevelopment())
//            {
//                app.UseSwagger();
//                app.UseSwaggerUI();
//            }
//            app.UseExceptionHandler(appError =>
//            {
//                appError.Run(async context =>
//                {
//                    context.Response.ContentType = "application/json";
//                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();

//                    if (contextFeature != null)
//                    {
//                        await context.Response.WriteAsync(new ErrorDetails()
//                        {
//                            StatusCode = context.Response.StatusCode,
//                            Message = contextFeature.Error.Message
//                        }.ToString());
//                    }
//                });
//            });


//            app.UseAuthentication();
//            app.UseAuthorization();


//            app.MapControllers();

//            app.Run();
//        }
//    }
//}using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using ProjectandManagementBackEnd.DAI;
using ProjectandManagementBackEnd.Models;
using ProjectandManagementBackEnd.Services;
using System.Text;

namespace ProjectandManagementBackEnd
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
           

           
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseMySql(
                    builder.Configuration.GetConnectionString("DefaultConnection"),
                    new MySqlServerVersion(new Version(8, 0, 33)),
                    mysqlOptions => mysqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 5,
                        maxRetryDelay: TimeSpan.FromSeconds(30),
                        errorNumbersToAdd: null)
                )
            );
            builder.Services.AddScoped<NotificationService>();
            // Configure JWT Authentication
            var jwtKey = builder.Configuration["Jwt:Key"] ?? throw new InvalidOperationException("JWT Key not configured");
            //builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            //    .AddJwtBearer(options =>
            //    {
            //        options.TokenValidationParameters = new TokenValidationParameters
            //        {
            //            ValidateIssuer = true,
            //            ValidateAudience = true,
            //            ValidateLifetime = true,
            //            ValidateIssuerSigningKey = true,
            //            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            //            ValidAudience = builder.Configuration["Jwt:Audience"],
            //            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
            //            ClockSkew = TimeSpan.Zero
            //        };
            //    });

            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
        };
    });

            // Add authorization
            builder.Services.AddAuthorization(options =>
            {
                options.AddPolicy("ManagerOnly", policy =>
                    policy.RequireRole("Manager"));
            });
            // Configure Email Service
            builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("EmailSettings"));
            builder.Services.AddTransient<IEmailSender, EmailSender>();
            // Add Controllers
            builder.Services.AddControllers();

            // Configure Swagger/OpenAPI
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen(c =>
               {
                        c.SwaggerDoc("v1", new OpenApiInfo { Title = "API", Version = "v1" });

                      var securityScheme = new OpenApiSecurityScheme
                      {
                        Name = "JWT Authentication",
                            Description = "Enter JWT Bearer token",
                         In = ParameterLocation.Header,
                            Type = SecuritySchemeType.Http,
                          Scheme = "bearer",
                             BearerFormat = "JWT",
                             Reference = new OpenApiReference
                             {
                                  Id = JwtBearerDefaults.AuthenticationScheme,
                                  Type = ReferenceType.SecurityScheme
                              }
                      };

                      c.AddSecurityDefinition(securityScheme.Reference.Id, securityScheme);
                        c.AddSecurityRequirement(new OpenApiSecurityRequirement
             {
               { securityScheme, Array.Empty<string>() }
           });
                });


           // Configure CORS
           builder.Services.AddCors(options =>
            {
                options.AddDefaultPolicy(builder =>
                {
                    builder.WithOrigins(
                            "http://localhost:5173",
                            "https://localhost:5173"
                        )
                        .AllowAnyHeader()
                        .AllowAnyMethod()
                        .AllowCredentials();
                });
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "API v1");
                    c.ConfigObject.AdditionalItems["syntaxHighlight"] = new Dictionary<string, object>
                    {
                        ["activated"] = false
                    };
                    c.RoutePrefix = "swagger";
                });
            }

            // Global error handling
            app.UseExceptionHandler(errorApp =>
            {
                errorApp.Run(async context =>
                {
                    context.Response.ContentType = "application/json";
                    var exceptionHandlerPathFeature = context.Features.Get<IExceptionHandlerPathFeature>();

                    if (exceptionHandlerPathFeature?.Error != null)
                    {
                        await context.Response.WriteAsync(new ErrorDetails
                        {
                            StatusCode = context.Response.StatusCode,
                            Message = exceptionHandlerPathFeature.Error.Message
                        }.ToString());
                    }
                });
            });

            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseCors();
            app.UseAuthentication();
            app.UseAuthorization();
            
            app.MapControllers();

            app.Run();
        }
    }
}