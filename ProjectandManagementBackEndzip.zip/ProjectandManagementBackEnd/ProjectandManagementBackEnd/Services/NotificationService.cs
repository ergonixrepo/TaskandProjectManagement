﻿// Services/NotificationService.cs
using Microsoft.EntityFrameworkCore;
using ProjectandManagementBackEnd.DAI;
using ProjectandManagementBackEnd.Models;
using ProjectandManagementBackEnd.Models.DTOs;
using System;

public class NotificationService
{
    private readonly ApplicationDbContext _db;

    public NotificationService(ApplicationDbContext db)
    {
        _db = db;
    }

    // Get all notifications for a user
    public async Task<List<Notification>> GetUserNotifications(int userId)
    {
        return await _db.Notifications
            .Where(n => n.UserId == userId)
            .OrderByDescending(n => n.CreatedAt)
            .ToListAsync();
    }

    // Create a new notification
    public async Task CreateNotification(int userId, int createdBy, string message)
    {
        var notification = new Notification
        {
            UserId = userId,
            CreatedBy = createdBy,
            Message = message
        };

        _db.Notifications.Add(notification);
        await _db.SaveChangesAsync();
    }

    // Mark notification as read
    public async Task MarkAsRead(int notificationId)
    {
        var notification = await _db.Notifications.FindAsync(notificationId);
        if (notification != null)
        {
            notification.IsRead = true;
            await _db.SaveChangesAsync();
        }
    }
    public async Task<List<Notification>> GetNotificationsSentByManager(int managerId)
    {
        return await _db.Notifications
            .Where(n => n.CreatedBy == managerId)
            .OrderByDescending(n => n.CreatedAt)
            .ToListAsync();
    }
    public async Task<int> GetUnreadCount()
    {
        return await _db.Notifications
                        .CountAsync(n => !n.IsRead);
    }
}