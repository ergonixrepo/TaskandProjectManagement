package com.example.TaskAndProjectManagement.DTO;

import java.time.LocalDate;
import java.util.List;

public class ProjectTaskResponse {
    private Integer projectId;
    private List<TaskDetails> tasks;
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public List<TaskDetails> getTasks() {
		return tasks;
	}
	public void setTasks(List<TaskDetails> tasks) {
		this.tasks = tasks;
	}
	public ProjectTaskResponse(Integer projectId, List<TaskDetails> tasks) {
		super();
		this.projectId = projectId;
		this.tasks = tasks;
	}

    // Constructors, getters, setters
    
}

