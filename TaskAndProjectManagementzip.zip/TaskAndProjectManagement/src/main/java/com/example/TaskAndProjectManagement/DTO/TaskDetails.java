package com.example.TaskAndProjectManagement.DTO; // or use your package name

import java.time.LocalDate;

public class TaskDetails {
    private Integer taskId;
    private String title;
    private String description;
    private String status;
    private LocalDate deadline;

    public TaskDetails() {}

    public TaskDetails(Integer taskId, String title, String description, String status, LocalDate deadline) {
        this.taskId = taskId;
        this.title = title;
        this.description = description;
        this.status = status;
        this.deadline = deadline;
    }

    // Getters and Setters
    public Integer getTaskId() {
        return taskId;
    }

    public void setTaskId(Integer taskId) {
        this.taskId = taskId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }
}
