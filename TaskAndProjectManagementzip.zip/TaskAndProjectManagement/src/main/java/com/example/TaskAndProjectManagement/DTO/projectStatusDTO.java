package com.example.TaskAndProjectManagement.DTO;

public class projectStatusDTO {
    private Integer projectId;
    private String status;
    private long pendingTaskCount;

    // Constructors
    public projectStatusDTO(Integer projectId, String status, long pendingTaskCount) {
        this.projectId = projectId;
        this.status = status;
        this.pendingTaskCount = pendingTaskCount;
    }

    // Getters and Setters
    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getPendingTaskCount() {
        return pendingTaskCount;
    }

    public void setPendingTaskCount(long pendingTaskCount) {
        this.pendingTaskCount = pendingTaskCount;
    }
}
