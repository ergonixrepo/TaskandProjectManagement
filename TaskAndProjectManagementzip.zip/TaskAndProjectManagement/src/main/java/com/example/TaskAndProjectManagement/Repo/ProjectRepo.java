package com.example.TaskAndProjectManagement.Repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.TaskAndProjectManagement.model.Project;

public interface ProjectRepo extends JpaRepository<Project, Integer> {

	Project save(Project project);

	List<Project> findAll();

	Optional<Project> findById(Integer id);

	void deleteById(Integer id);
	
	 List<Project> findByCreatedByManagerId(Long userId);

	

	
} 
