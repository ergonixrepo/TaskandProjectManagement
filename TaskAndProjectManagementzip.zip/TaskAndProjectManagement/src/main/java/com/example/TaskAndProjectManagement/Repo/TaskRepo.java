package com.example.TaskAndProjectManagement.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.TaskAndProjectManagement.model.Task;
import com.example.TaskAndProjectManagement.model.TaskStatus;
//import org.springframework.scheduling.config.Task;

public interface TaskRepo extends JpaRepository<Task, Integer> {

	List<Task> findByAssignedToId(Long employeeId);

	List<Task> findByProjectId(Integer projectId);

//	  long countByProjectIdAndStatus(Integer projectId, TaskStatus status);
	long countByProjectIdAndStatusIn(Integer projectId, List<TaskStatus> statuses);


}
