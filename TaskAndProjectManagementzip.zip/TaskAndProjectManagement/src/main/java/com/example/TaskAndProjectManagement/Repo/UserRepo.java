package com.example.TaskAndProjectManagement.Repo;



import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.TaskAndProjectManagement.model.User;

public  interface UserRepo extends JpaRepository<User, Long>{
	
	//created for login api
	 Optional<User> findByEmailAndPassword(String email, String password);
 //for validation while login
	boolean existsByEmail(String email);

	boolean existsByPassword(String password);

}
