package com.example.TaskAndProjectManagement.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.TaskAndProjectManagement.DTO.projectStatusDTO;
import com.example.TaskAndProjectManagement.Repo.ProjectRepo;
import com.example.TaskAndProjectManagement.Repo.TaskRepo;
import com.example.TaskAndProjectManagement.model.Project;
import com.example.TaskAndProjectManagement.model.TaskStatus;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private ProjectRepo projectRepo;

    @Autowired
    private TaskRepo taskRepo;
    
    
    @GetMapping("/project-status-summary")
    public ResponseEntity<List<projectStatusDTO>> getProjectStatusSummary() {
        List<Project> projects = projectRepo.findAll();
        List<projectStatusDTO> summaryList = new ArrayList<>();

        for (Project project : projects) {
            // Count both PENDING and IN_PROGRESS tasks
            long pendingCount = taskRepo.countByProjectIdAndStatusIn(
                    project.getId(),
                    List.of(TaskStatus.PENDING, TaskStatus.IN_PROGRESS)
            );

            projectStatusDTO dto = new projectStatusDTO(
                    project.getId(),
                    project.getStatus().toString(),
                    pendingCount
            );
            summaryList.add(dto);
        }

        return ResponseEntity.ok(summaryList);
    }

}
