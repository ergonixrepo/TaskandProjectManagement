package com.example.TaskAndProjectManagement.controller;


import com.example.TaskAndProjectManagement.Repo.TaskRepo;
import com.example.TaskAndProjectManagement.model.Task;
import com.example.TaskAndProjectManagement.model.User;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/email")
public class EmailController {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private TaskRepo taskRepository;

    @GetMapping("/sendReminder")
    public String sendDeadlineReminder() {
        LocalDate today = LocalDate.now();
        LocalDate reminderDate = today.plusDays(2);

        List<Task> tasks = taskRepository.findAll();

        int emailCount = 0;
        for (Task task : tasks) {
            if (task.getDeadline() != null && reminderDate.equals(task.getDeadline())) {
                User employee = task.getAssignedTo();
                if (employee != null && employee.getEmail() != null) {
                    sendEmail(employee.getEmail(), task.getTitle(), task.getDeadline());
                    emailCount++;
                }
            }
        }

        return "Emails sent: " + emailCount;
    }

    private void sendEmail(String toEmail, String taskTitle, LocalDate deadline) {
        SimpleMailMessage message = new SimpleMailMessage(); //simple mail msg is inbuild obj 
        message.setTo(toEmail);
        message.setSubject("⏰ Task Deadline Reminder");
        message.setText("Dear Employee,\n\n Our records show that the task has not yet been marked as completed. As the deadline is just 2 days away, you are kindly requested to review the task and take necessary action to ensure it is completed on time.\r\n"
        		+ "\r\n"
        		+ "If you are experiencing any blockers or require support, please inform your reporting manager promptly to avoid delays in the project timeline.\r\n"

        	
        		
        		+ "\n\n📌 Task Title: '" + taskTitle + "' "
        				+ "\n\n📅 Deadline: " + deadline +
                "\n\n Please complete it before the due date.\n\n"
        		 

               
                + "Thank you for your attention and timely action."
                + "\n\nBest regards,"
                + "\nTask Management System"
                + "\n\n\n\n🔔 This is a system-generated email. Please do not reply directly to this message.");

        mailSender.send(message);
    }
}
