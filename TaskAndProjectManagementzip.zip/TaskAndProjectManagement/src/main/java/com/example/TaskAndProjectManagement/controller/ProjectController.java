package com.example.TaskAndProjectManagement.controller;
import com.example.TaskAndProjectManagement.Repo.ProjectRepo;
import com.example.TaskAndProjectManagement.Repo.TaskRepo;
import com.example.TaskAndProjectManagement.Repo.UserRepo;
import com.example.TaskAndProjectManagement.model.Project;
import com.example.TaskAndProjectManagement.model.ProjectStatus;
import com.example.TaskAndProjectManagement.model.Task;
import com.example.TaskAndProjectManagement.model.TaskStatus;
import com.example.TaskAndProjectManagement.model.User;
import com.example.TaskAndProjectManagement.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/projects")
@CrossOrigin(origins = "*") // Optional: For React/Postman access
	public class ProjectController {

	    @Autowired
	    private ProjectService projectService;
	    
	    @Autowired
	    private UserRepo userRepo;
	    @Autowired
	    private ProjectRepo projectRepo;
	    
	    @Autowired
	    private TaskRepo taskRepo;
	    
	    
	    //To add new project with manager id & manager details in JSON
	    @PostMapping("/addproject")
	    public ResponseEntity<?> createProject(@RequestBody Project project, @RequestParam Long userId) {
	        Optional<User> optionalUser = userRepo.findById(userId);
	        if (optionalUser.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
	        }

	        //user class called to get role 
	        User user = optionalUser.get();

	        if (!"manager".equalsIgnoreCase(user.getRole())) {
	            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Only a manager can create a project");
	        }

	        project.setCreatedByManager(user);//set project manager id in project table(database)
	        Project savedProject = projectService.createProject(project);
	        return ResponseEntity.status(HttpStatus.CREATED).body(savedProject);
	    }

	    
	    //specific manager can get all projects. [View Project]
	    @GetMapping("/getAllProjects")
	    public ResponseEntity<?> getProjectsByManager(@RequestParam("userId") Long userId) {
	        Optional<User> optionalUser = userRepo.findById(userId);
	        
	        if (optionalUser.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
	        }

	        User user = optionalUser.get();

	        // Only allow manager to view their projects
	        if (!"manager".equalsIgnoreCase(user.getRole())) {
	            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Only a manager can view their created projects");
	        }

	        List<Project> projects = projectRepo.findByCreatedByManagerId(userId);
	        return ResponseEntity.ok(projects);
	    }


//	  
//	    @GetMapping("/getProjectWithTasks/{id}")
//	    public ResponseEntity<Project> getProjectWithTasks(@PathVariable Integer id) {
//	        Project project = projectService.getProjectById(id)
//	                .orElseThrow(() -> new RuntimeException("Project not found with id: " + id));
//	        return ResponseEntity.ok(project);
//	    }


//	    @PutMapping("/{UpdateProjectById}")
//	    public Project updateProject(@PathVariable Integer id, @RequestBody Project project) {
//	        return projectService.updateProject(id, project);
//	    }
//
//	    @DeleteMapping("/{id}")
//	    public void deleteProject(@PathVariable Integer id) {
//	        projectService.deleteProject(id);
//	    }
	    
//	    @PutMapping("/updateStatus/{projectId}")
//	    public ResponseEntity<String> updateProjectStatus(@PathVariable Integer projectId) {
//	        Optional<Project> optionalProject = projectRepo.findById(projectId);
//	        if (optionalProject.isEmpty()) {
//	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found");
//	        }
//
//	        Project project = optionalProject.get();
//	        List<Task> tasks = taskRepo.findByProjectId(projectId);
//
//	        if (tasks.isEmpty()) {
//	            project.setStatus(ProjectStatus.PLANNED);
//	        } else {
//	            boolean allCompleted = true;
//	            for (Task task : tasks) {
//	                if (!task.getStatus().equals(TaskStatus.COMPLETED)) {
//	                    allCompleted = false;
//	                    break;
//	                }
//	            }
//
//	            if (allCompleted) {
//	                project.setStatus(ProjectStatus.COMPLETED);
//	            } else {
//	                project.setStatus(ProjectStatus.IN_PROGRESS);
//	            }
//	        }
//
//	        projectRepo.save(project);
//	        return ResponseEntity.ok("Project status updated to: " + project.getStatus());
//	    }
	    @PutMapping("/updateStatus/{projectId}")
	    public ResponseEntity<String> updateProjectStatus(@PathVariable Integer projectId) {
	        Optional<Project> optionalProject = projectRepo.findById(projectId);
	        if (optionalProject.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found");
	        }

	        Project project = optionalProject.get();
	        List<Task> tasks = taskRepo.findByProjectId(projectId);

	        if (tasks.isEmpty()) {
	            project.setStatus(ProjectStatus.PLANNED);
	        } else if (tasks.stream().allMatch(task -> task.getStatus().equals(TaskStatus.COMPLETED))) {
	            project.setStatus(ProjectStatus.COMPLETED);
	        } else if (tasks.stream().anyMatch(task -> task.getAssignedTo() != null)) {
	            project.setStatus(ProjectStatus.IN_PROGRESS);
	        } else {
	            project.setStatus(ProjectStatus.PLANNED); // Not assigned to anyone yet
	        }

	        projectRepo.save(project);
	        return ResponseEntity.ok("Project status updated to: " + project.getStatus());
	    }

	}



