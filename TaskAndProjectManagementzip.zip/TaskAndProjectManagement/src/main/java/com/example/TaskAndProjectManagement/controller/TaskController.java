package com.example.TaskAndProjectManagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.TaskAndProjectManagement.Repo.ProjectRepo;
import com.example.TaskAndProjectManagement.Repo.TaskRepo;
import com.example.TaskAndProjectManagement.Repo.UserRepo;
import com.example.TaskAndProjectManagement.model.Project;
import com.example.TaskAndProjectManagement.model.Task;
import com.example.TaskAndProjectManagement.model.TaskStatus;
import com.example.TaskAndProjectManagement.model.User;
import com.example.TaskAndProjectManagement.service.TaskService;
//import com.example.TaskAndProjectManagement.Repo.TaskRepo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

	    @Autowired
	    private TaskService taskService;
	    @Autowired
	    ProjectRepo projectRepo;
	    @Autowired
	    UserRepo userRepo;
	    @Autowired
	    TaskRepo taskRepo;
	    
	    
	    //add a new task in specific project
	    @PostMapping("/addTask")
	    public ResponseEntity<?> createTask(
	            @RequestBody Task task,
	            @RequestParam Integer projectId) {

	        Optional<Project> projectOpt = projectRepo.findById(projectId);
	        
	        if (projectOpt.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Project not found");
	        }

	        Project project = projectOpt.get();

	        task.setProject(project); // Set the associated project
	        task.setCreated_By_Manager_id(project.getCreatedByManager());

	        Task savedTask = taskService.createTask(task);
	        return ResponseEntity.ok(savedTask);
	    }
	    
	    //assign a task to specific user with specific project
	    @PutMapping("/assignTask")
	    public ResponseEntity<?> assignTaskToEmployee(
	            @RequestParam Integer taskId,
	            @RequestParam Long employeeId) {

	        Optional<Task> taskOpt = taskRepo.findById(taskId);//optional does not give null pointer exception
	        if (taskOpt.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Task not found");
	        }

	        Optional<User> employeeOpt = userRepo.findById(employeeId);
	        if (employeeOpt.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found");
	        }

	        User employee = employeeOpt.get();
	        if (!"employee".equalsIgnoreCase(employee.getRole())) {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("User is not an employee");
	        }

	        Task task = taskOpt.get();
	        task.setAssignedTo(employee); // Assign the employee

	        taskService.createTask(task); // Save updated task

	        return ResponseEntity.ok("Task assigned successfully");
	    }

	    
	    @GetMapping("/getTasksByEmployee")
	    public ResponseEntity<?> getTasksByEmployee(@RequestParam Long employeeId) {
	        Optional<User> userOpt = userRepo.findById(employeeId);
	        if (userOpt.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found");
	        }

	        List<Task> tasks = taskRepo.findByAssignedToId(employeeId);

	        // Group tasks by project ID
	        Map<Integer, List<Map<String, Object>>> grouped = new LinkedHashMap<>();

	        for (Task task : tasks) {
	            Integer projectId = task.getProject().getId();

	            Map<String, Object> taskMap = new LinkedHashMap<>();
	            taskMap.put("task_id", task.getId());
	            taskMap.put("title", task.getTitle());
	            taskMap.put("description", task.getDescription());
	            taskMap.put("status", task.getStatus().toString());
	            taskMap.put("deadline", task.getDeadline());

	            grouped.computeIfAbsent(projectId, k -> new ArrayList<>()).add(taskMap);
	        }

	        // Build final response
	        List<Map<String, Object>> response = new ArrayList<>();

	        for (Map.Entry<Integer, List<Map<String, Object>>> entry : grouped.entrySet()) {
	            Map<String, Object> projectTasks = new LinkedHashMap<>();
	            projectTasks.put("Project_id", entry.getKey());
	            projectTasks.put("tasks", entry.getValue());
	            response.add(projectTasks);
	        }

	        return ResponseEntity.ok(response);
	    }
	    @DeleteMapping("/deleteTask/{id}")
	    public ResponseEntity<Integer> deleteTask(@PathVariable Integer id) {
	        boolean deleted = taskService.deleteTask(id);
	        return ResponseEntity.ok(deleted ? 1 : 0);  // 1 = deleted, 0 = not found
	    }


//	    @GetMapping
//	    public ResponseEntity<List<Task>> getAllTasks() {
//	        return ResponseEntity.ok(taskService.getAllTasks());
//	    }
	    
//	    
//        @GetMapping("/{id}")
//	    public ResponseEntity<Task> getTaskById(@PathVariable Integer id) {
//	        return taskService.getTaskById(id)
//	                .map(ResponseEntity::ok)
//	                .orElse(ResponseEntity.notFound().build());
//	    }
//        
        
//        @PutMapping("/{id}")
//	    public ResponseEntity<Task> updateTask(@PathVariable Integer id, @RequestBody Task task) {
//	        return ResponseEntity.ok(taskService.updateTask(id, task));
//	    }
        

	    @PutMapping("/updateStatus/{taskId}")
	    public ResponseEntity<String> updateTaskStatus(
	            @PathVariable Integer taskId,
	            @RequestBody Map<String, String> body
	    ) {
	        Optional<Task> optionalTask = taskRepo.findById(taskId);
	        if (optionalTask.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Task not found");
	        }

	        Task task = optionalTask.get();
	        String newStatus = body.get("status"); // from frontend

	        try {
	            TaskStatus statusEnum = TaskStatus.valueOf(newStatus.toUpperCase());
	            task.setStatus(statusEnum);
	            taskRepo.save(task);
	            return ResponseEntity.ok("Task status updated to: " + statusEnum);
	        } catch (IllegalArgumentException e) {
	            return ResponseEntity.badRequest().body("Invalid status: " + newStatus);
	        }
	    }


}



