package com.example.TaskAndProjectManagement.controller;


import com.example.TaskAndProjectManagement.DTO.LoginRequest;
import com.example.TaskAndProjectManagement.DTO.UserResponse;
import com.example.TaskAndProjectManagement.Repo.UserRepo;
import com.example.TaskAndProjectManagement.model.User;
import com.example.TaskAndProjectManagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    UserRepo userRepo;
    
    
    //api created for login page which give response based on dto(user response class
    
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        Optional<User> optionalUser = userRepo.findByEmailAndPassword(
                request.getEmail(), request.getPassword());

        if (optionalUser.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        }

        User user = optionalUser.get(); // get sql user table data 

        UserResponse response = new UserResponse(
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getGender(),
                user.getJobDesignation(),
                user.getNoOfYearsExperience(),
                user.getPhonenumber(),
                user.getRole()
        );

        return ResponseEntity.ok(response);
    }

//api for register
    @PostMapping("/addUser")
    public ResponseEntity<?> createUser(@RequestBody User user) {
        try {
            User savedUser = userService.createUser(user);
            return ResponseEntity.ok(savedUser);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }
//    @PostMapping("/addUser")
//    public User createUser(@RequestBody User user) {
//        return userService.createUser(user);
//    }

//    @GetMapping
//    public List<User> getAllUsers() {
//        return userService.getAllUsers();
//    }
//
//    @GetMapping("/{id}")
//    public User getUserById(@PathVariable Long id) {
//        return userService.getUserById(id);
//    }
//
//    @PutMapping("/{id}")
//    public User updateUser(@PathVariable Long id, @RequestBody User user) {
//        return userService.updateUser(id, user);
//    }
//
//    @DeleteMapping("/{id}")
//    public void deleteUser(@PathVariable Long id) {
//        userService.deleteUser(id);
//    }
}



