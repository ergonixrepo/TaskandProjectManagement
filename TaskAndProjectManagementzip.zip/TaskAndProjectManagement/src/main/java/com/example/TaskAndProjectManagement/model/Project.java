package com.example.TaskAndProjectManagement.model;

	import jakarta.persistence.*;
	import java.time.LocalDate;
	import java.util.ArrayList;
	import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

	@Entity
	@Table(name = "projects")
	public class Project {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer id;

	    @Column(nullable = false)
	    private String name;

	    private String description;

	    private LocalDate startDate;

	    private LocalDate endDate;
	    
	    @ManyToOne
	    @JoinColumn(name = "created_by_manager_id")
	    private User createdByManager;
	    
	    public User getCreatedByManager() {
	        return createdByManager;
	    }

	    public void setCreatedByManager(User createdByManager) {
	        this.createdByManager = createdByManager;
	    }


	    @Enumerated(EnumType.STRING)
	    private ProjectStatus status = ProjectStatus.PLANNED;

	    // Optional: One-to-many relationship with tasks
	    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
	    @JsonManagedReference
	    private List<Task> tasks = new ArrayList<>();

	    // Constructors
	    public Project() {}

	    public Project(String name, String description, LocalDate startDate, LocalDate endDate, ProjectStatus status) {
	        this.name = name;
	        this.description = description;
	        this.startDate = startDate;
	        this.endDate = endDate;
	        this.status = status;
	    }

	    // Getters and Setters

	    public Integer getId() {
	        return id;
	    }

	    public void setId(Integer id) {
	        this.id = id;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public LocalDate getStartDate() {
	        return startDate;
	    }

	    public void setStartDate(LocalDate startDate) {
	        this.startDate = startDate;
	    }

	    public LocalDate getEndDate() {
	        return endDate;
	    }

	    public void setEndDate(LocalDate endDate) {
	        this.endDate = endDate;
	    }

	    public ProjectStatus getStatus() {
	        return status;
	    }

	    public void setStatus(ProjectStatus status) {
	        this.status = status;
	    }

	    public List<Task> getTasks() {
	        return tasks;
	    }

	    public void setTasks(List<Task> tasks) {
	        this.tasks = tasks;
	    }
	}



