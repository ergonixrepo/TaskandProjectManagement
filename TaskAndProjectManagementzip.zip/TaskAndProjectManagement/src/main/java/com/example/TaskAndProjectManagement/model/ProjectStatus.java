package com.example.TaskAndProjectManagement.model;


public enum ProjectStatus {
    PLANNED,
    IN_PROGRESS,
    COMPLETED
}
