package com.example.TaskAndProjectManagement.model;


import jakarta.persistence.*;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "tasks")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String title;
    
    
    @ManyToOne
    @JoinColumn(name = "assigned_to")
    private User assignedTo;


    private String description;

    @Enumerated(EnumType.STRING)
    private TaskStatus status = TaskStatus.PENDING;

    private LocalDate deadline;

//    @ManyToOne
//    @JoinColumn(name = "assigned_to")
//    private User assignedTo;
//
    @ManyToOne
    @JoinColumn(name = "created_by_manager_id")
    private User created_By_Manager_id; // this must be a manager

//
    @ManyToOne
    @JoinColumn(name = "project_id")
    @JsonBackReference
    private Project project;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public User getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(User assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public TaskStatus getStatus() {
		return status;
	}

	public void setStatus(TaskStatus status) {
		this.status = status;
	}

	public LocalDate getDeadline() {
		return deadline;
	}

	public void setDeadline(LocalDate deadline) {
		this.deadline = deadline;
	}

	public User getCreated_By_Manager_id() {
		return created_By_Manager_id;
	}

	public void setCreated_By_Manager_id(User created_By_Manager_id) {
		this.created_By_Manager_id = created_By_Manager_id;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", title=" + title + ", assignedTo=" + assignedTo + ", description=" + description
				+ ", status=" + status + ", deadline=" + deadline + ", created_By_Manager_id=" + created_By_Manager_id
				+ ", project=" + project + "]";
	}

	public Task(Integer id, String title, User assignedTo, String description, TaskStatus status, LocalDate deadline,
			User created_By_Manager_id, Project project) {
		super();
		this.id = id;
		this.title = title;
		this.assignedTo = assignedTo;
		this.description = description;
		this.status = status;
		this.deadline = deadline;
		this.created_By_Manager_id = created_By_Manager_id;
		this.project = project;
	}

	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	
   
    
}
