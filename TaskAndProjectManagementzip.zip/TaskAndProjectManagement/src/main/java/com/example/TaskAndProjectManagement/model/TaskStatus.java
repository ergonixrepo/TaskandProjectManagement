package com.example.TaskAndProjectManagement.model;

public enum TaskStatus {
	    
	    PENDING,
	    IN_PROGRESS,
	    COMPLETED
	}



