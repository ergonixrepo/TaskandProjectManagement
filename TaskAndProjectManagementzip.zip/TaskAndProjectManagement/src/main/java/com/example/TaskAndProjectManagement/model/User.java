package com.example.TaskAndProjectManagement.model;

	import jakarta.persistence.Entity;
	import jakarta.persistence.GeneratedValue;
	import jakarta.persistence.GenerationType;
	import jakarta.persistence.Id;
import jakarta.persistence.Table;


	@Entity	
	@Table(name="users")

	public class User {
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		long id;
		String Name;
	
		String email;
		String password;
		String role;//employee,manager,ceo
		int noOfYearsExperience;
		String gender;
		String jobDesignation;
		long phonenumber;
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public int getNoOfYearsExperience() {
			return noOfYearsExperience;
		}
		public void setNoOfYearsExperience(int noOfYearsExperience) {
			this.noOfYearsExperience = noOfYearsExperience;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getJobDesignation() {
			return jobDesignation;
		}
		public void setJobDesignation(String jobDesignation) {
			this.jobDesignation = jobDesignation;
		}
		public long getPhonenumber() {
			return phonenumber;
		}
		public void setPhonenumber(long phonenumber) {
			this.phonenumber = phonenumber;
		}
		@Override
		public String toString() {
			return "User [id=" + id + ", Name=" + Name + ", email=" + email + ", password=" + password + ", role="
					+ role + ", noOfYearsExperience=" + noOfYearsExperience + ", gender=" + gender + ", jobDesignation="
					+ jobDesignation + ", phonenumber=" + phonenumber + "]";
		}
		public User(long id, String name, String email, String password, String role, int noOfYearsExperience,
				String gender, String jobDesignation, long phonenumber) {
			super();
			this.id = id;
			Name = name;
			this.email = email;
			this.password = password;
			this.role = role;
			this.noOfYearsExperience = noOfYearsExperience;
			this.gender = gender;
			this.jobDesignation = jobDesignation;
			this.phonenumber = phonenumber;
		}
		public User() {
			super();
			// TODO Auto-generated constructor stub
		}
		
	}



