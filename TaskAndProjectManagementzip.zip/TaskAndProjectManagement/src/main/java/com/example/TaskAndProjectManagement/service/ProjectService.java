package com.example.TaskAndProjectManagement.service;
import com.example.TaskAndProjectManagement.Repo.ProjectRepo;
import com.example.TaskAndProjectManagement.model.Project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service


	public class ProjectService {

	    @Autowired
	    private ProjectRepo projectRepository;

	    public Project createProject(Project project) {
	        return projectRepository.save(project);
	    }

	    public List<Project> getAllProjects() {
	        return projectRepository.findAll();
	    }

	    public Optional<Project> getProjectById(Integer id) {
	        return projectRepository.findById(id);
	    }

	    public Project updateProject(Integer id, Project updatedProject) {
	        return projectRepository.findById(id).map(project -> {
	            project.setName(updatedProject.getName());
	            project.setDescription(updatedProject.getDescription());
	            project.setStartDate(updatedProject.getStartDate());
	            project.setEndDate(updatedProject.getEndDate());
	            project.setStatus(updatedProject.getStatus());
	            return projectRepository.save(project);
	        }).orElseThrow(() -> new RuntimeException("Project not found with id: " + id));
	    }

	    public void deleteProject(Integer id) {
	        projectRepository.deleteById(id);
	    }
	}



