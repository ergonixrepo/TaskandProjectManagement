package com.example.TaskAndProjectManagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.TaskAndProjectManagement.Repo.TaskRepo;
import com.example.TaskAndProjectManagement.model.Task;
import com.example.TaskAndProjectManagement.model.TaskStatus;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
	
	    @Autowired
	    private TaskRepo taskRepository;

	    public Task createTask(Task task) {
	        return taskRepository.save(task);
	    }

	    public List<Task> getAllTasks() {
	        return taskRepository.findAll();
	    }

	    public Optional<Task> getTaskById(Integer id) {
	        return taskRepository.findById(id);
	    }
	    public List<Task> getTasksByEmployee(int employeeId) {
	        return taskRepository.findByAssignedToId((long) employeeId);  // cast to Long
	    }



//	    public Task updateTask(Integer id, Task updatedTask) {
//	        Task task = taskRepository.findById(id).orElseThrow();
//	        task.setTitle(updatedTask.getTitle());
//	        task.setDescription(updatedTask.getDescription());
//	        task.setStatus(updatedTask.getStatus());
//	        task.setDeadline(updatedTask.getDeadline());
//	        task.setAssignedTo(updatedTask.getAssignedTo());
//	        task.setCreatedBy(updatedTask.getCreatedBy());
//	        task.setProject(updatedTask.getProject());
//	        return taskRepository.save(task);
//	    }

//	    public void deleteTask(Integer id) {
//	        taskRepository.deleteById(id);
//	    }
//	    
	    public boolean deleteTask(Integer id) {
	        if (taskRepository.existsById(id)) {
	            taskRepository.deleteById(id);
	            return true; // deletion successful
	        } else {
	            return false; // task not found
	        }
	    }


	    public Task updateStatus(Integer id, TaskStatus status) {
	        Task task = taskRepository.findById(id).orElseThrow();
	        task.setStatus(status);
	        return taskRepository.save(task);
	    }
	}


