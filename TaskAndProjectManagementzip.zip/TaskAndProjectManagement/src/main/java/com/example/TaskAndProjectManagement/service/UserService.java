package com.example.TaskAndProjectManagement.service;
import com.example.TaskAndProjectManagement.Repo.UserRepo;
import com.example.TaskAndProjectManagement.model.User;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

	public class UserService {

	    @Autowired
	    private UserRepo userRepository;

//	   for register new user
 	    public User createUser(User user) {
	        if (userRepository.existsByEmail(user.getEmail())) {
	            throw new RuntimeException("Email already exists");
	        }

	        if (userRepository.existsByPassword(user.getPassword())) {
	            throw new RuntimeException("Password already exists");
	        }

	        return userRepository.save(user);
	    }
 	    
 	    
//
//	    public List<User> getAllUsers() {
//	        return userRepository.findAll();
//	    }
//
//	    public User getUserById(Long id) {
//	        return userRepository.findById(id).orElse(null);
//	    }
//
//	    public User updateUser(Long id, User updatedUser) {
//	        User user = userRepository.findById(id).orElse(null);
//	        if (user != null) {
//	            user.setName(updatedUser.getName());
//	            user.setEmail(updatedUser.getEmail());
//	            user.setPassword(updatedUser.getPassword());
//	            user.setRole(updatedUser.getRole());
//	            user.setNoOfYearsExperience(updatedUser.getNoOfYearsExperience());
//	            user.setGender(updatedUser.getGender());
//	            return userRepository.save(user);
//	        }
//	        return null;
//	    }
//
//	    public void deleteUser(Long id) {
//	        userRepository.deleteById(id);
//	    }
	}




