package com.example.TaskAndProjectManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskAndProjectManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
