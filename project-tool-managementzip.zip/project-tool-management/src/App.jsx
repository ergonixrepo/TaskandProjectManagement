import React, { useEffect } from 'react';
import AppRoutes from './routes/AppRoutes';
import { jwtDecode } from 'jwt-decode'; // ✅ fixed import

function App() {
   useEffect(() => {
  const token = localStorage.getItem("token");
  console.log("Token:", token);

  if (token) {
    try {
      const decoded = jwtDecode(token);
      console.log("Decoded token:", decoded);  // Full decoded object
      console.log("Decoded nameid:", decoded.nameid); // Specific field

      const empId = decoded.nameid;
      if (empId) {
        localStorage.setItem("employeeId", empId);
      } else {
        console.warn("❌ Employee ID not found in token.");
      }
    } catch (error) {
      console.error("❌ Error decoding token:", error);
    }
  }
}, []);

  return <AppRoutes />;
}

export default App;
