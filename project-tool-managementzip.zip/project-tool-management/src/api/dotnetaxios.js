
import axios from 'axios';

const instance = axios.create({
  baseURL: 'https://localhost:7094/api',
  timeout: 50000, 
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

// Request interceptor for auth token
instance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
instance.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle 401 Unauthorized (token expired)
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login'; // Redirect to login
    }
    
    // Handle 500 Server Errors
    if (error.response?.status === 500) {
      console.error('Server Error:', error.response.data);
    }
    
    return Promise.reject(error);
  }
);

// Add methods for common API calls
export const api = {
  // Auth methods
  login: (credentials) => instance.post('/Auth/Login', credentials),
  register: (userData) => instance.post('/Auth/Register', userData),
  
  // Teams
  getTeams: () => instance.get('/Teams'),
  createTeam: (teamData) => instance.post('/Teams', teamData),
  addTeamMember: (teamId, memberData) => 
    instance.post(`/Teams/${teamId}/members`, memberData),
  removeTeamMember: (teamId, userId) => 
    instance.delete(`/Teams/${teamId}/members/${userId}`)

};

export default instance;