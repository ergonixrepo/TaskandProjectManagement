import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Footer.css'; 

const Footer = () => {
  return (
    <footer className="footer text-dark pt-4 pb-2">
      <div className="container">
        <div className="row">
          {/* Logo and short intro */}
          <div className="col-md-4 mb-3">
            <h5 className="fw-bold">Workplace Manager</h5>
            <p className="small">
              Manage projects, tasks, and teams effortlessly in one place.
            </p>
          </div>

          {/* Quick Links */}
          <div className="col-md-4 mb-3">
            <h6 className="fw-bold">Quick Links</h6>
            <ul className="list-unstyled">
              <li><Link to="/" className="footer-link">Home</Link></li>
              <li><Link to="/about" className="footer-link">About</Link></li>
              <li><Link to="/contact" className="footer-link">Contact</Link></li>
              <li><Link to="/register" className="footer-link">Register</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="col-md-4 mb-3">
            <h6 className="fw-bold">Contact Us</h6>
            <p className="small mb-1">Email: <a href="mailto:support@workplacemanager.com" className="footer-link">support@workplacemanager.com</a></p>
            <p className="small mb-1">Phone: <a href="tel:+11234567890" className="footer-link">+1 (123) 456-7890</a></p>
            <p className="small mb-0">Address: Your Company Address Here</p>
          </div>
        </div>

        <hr className="bg-dark" />

        <div className="text-center small">
          &copy; {new Date().getFullYear()} Workplace Manager. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;