import React from 'react';
import { useNotifications } from '../hooks/useNotifications';
import { FaBell, FaSpinner } from 'react-icons/fa';

export function NotificationBell() {
  const { 
    notifications, 
    loading, 
    error, 
    fetchNotifications,
    markAsRead
  } = useNotifications();

  const handleNotificationClick = (id) => {
    markAsRead(id);
    // Additional click handling if needed
  };

  return (
    <div className="notification-bell">
      <button 
        onClick={fetchNotifications}
        disabled={loading}
        className="bell-button"
      >
        {loading ? (
          <FaSpinner className="spinner" />
        ) : (
          <>
            <FaBell />
            {notifications.filter(n => !n.isRead).length > 0 && (
              <span className="badge">
                {notifications.filter(n => !n.isRead).length}
              </span>
            )}
          </>
        )}
      </button>
      
      <div className="notification-dropdown">
        {error ? (
          <div className="error">
            {error}
            <button onClick={fetchNotifications}>Retry</button>
          </div>
        ) : notifications.length === 0 ? (
          <div className="empty">No notifications</div>
        ) : (
          notifications.map(notification => (
            <div 
              key={notification.id}
              className={`notification ${notification.isRead ? '' : 'unread'}`}
              onClick={() => handleNotificationClick(notification.id)}
            >
              <div className="message">{notification.message}</div>
              <div className="meta">
                <span>From: User {notification.createdBy}</span>
                <span>
                  {new Date(notification.createdAt).toLocaleString()}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}