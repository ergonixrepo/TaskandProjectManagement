
import React from 'react';
import { Navigate } from 'react-router-dom';

export default function RedirectBasedOnRole() {
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');

  if (!token) return <Navigate to="/login" replace />;
  if (role === 'manager') return <Navigate to="/manager-dashboard" replace />;
  if (role === 'employee') return <Navigate to="/employee-dashboard" replace />;

  // fallback
  return <Navigate to="/choose-role" replace />;
}
