import { useState, useEffect } from 'react';
import axios from '../api/dotnetaxios';
import { useNavigate } from 'react-router-dom';

export function useNotifications() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  // Matches: [HttpGet] GetNotifications(int userId)
  const fetchNotifications = async () => {
    console.group('Fetching Notifications');
    setLoading(true);
    setError(null);
    
    try {
      const token = localStorage.getItem('token');
      if (!token) throw new Error('No authentication token found');
      
      const userId = JSON.parse(atob(token.split('.')[1]))?.nameid;
      if (!userId) throw new Error('Unable to determine user ID');

      console.log('Calling GET /api/notifications?userId=' + userId);
      const response = await axios.get('/Notifications', {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          userId: userId  // Matches the GetNotifications parameter
        }
      });

      console.log('API Response:', response.data);
      setNotifications(response.data);
      
    } catch (error) {
      console.error('Fetch Error:', error);
      setError(error.response?.data?.message || error.message || 'Failed to fetch notifications');
      
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
      }
    } finally {
      setLoading(false);
      console.groupEnd();
    }
  };

  // Matches: [HttpPost] CreateNotification([FromBody] CreateNotificationRequest)
  const createNotification = async (receiverId, message) => {
    try {
      const token = localStorage.getItem('token');
      const createdBy = JSON.parse(atob(token.split('.')[1]))?.nameid;
      
      console.log('Calling POST /api/notifications');
      await axios.post('/Notifications', {
        UserId: receiverId,     // Matches CreateNotificationRequest.UserId
        CreatedBy: createdBy,   // Matches CreateNotificationRequest.CreatedBy
        Message: message        // Matches CreateNotificationRequest.Message
      }, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      await fetchNotifications(); // Refresh the list
      
    } catch (error) {
      console.error('Create Notification Error:', error);
      throw error;
    }
  };

  // Matches: [HttpPost("{id}/read")] MarkAsRead(int id)
  const markAsRead = async (id) => {
    try {
      const token = localStorage.getItem('token');
      
      console.log(`Calling POST /api/notifications/${id}/read`);
      await axios.post(`/Notifications/${id}/read`, {}, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      setNotifications(prev => 
        prev.map(n => n.id === id ? {...n, isRead: true} : n)
      );
      
    } catch (error) {
      console.error('Mark as Read Error:', error);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  return { 
    notifications, 
    loading, 
    error, 
    fetchNotifications,
    createNotification,
    markAsRead
  };
}