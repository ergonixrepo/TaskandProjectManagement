import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footers';
import '../styles/about.css';

const About = () => {
  return (
    <>
      <Navbar />

      <section className="about-hero text-center text-white d-flex align-items-center justify-content-center">
        <div>
          <h1 className="fw-bold heading">About Ergonix</h1>
          <p className="lead heading">Streamline projects, tasks, and teams in one place.</p>
        </div>
      </section>

      <section className="container py-5">
        <div className="row">
          <div className="col-md-6 mb-4">
            <h2 className="fw-bold">Our Mission</h2>
            <p>
              At Ergonix, we’re on a mission to make workplace management simple, clear, and productive.
              We help teams plan tasks, manage resources, and collaborate without hassle.
            </p>
          </div>
          <div className="col-md-6 mb-4">
            <h2 className="fw-bold">Our Story</h2>
            <p>
              We started Ergonix to solve the daily struggles teams face when juggling tools and tasks.
              Our goal is to provide an all-in-one system that keeps everyone on track and projects on time.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-light py-5">
        <div className="container">
          <h2 className="fw-bold text-center mb-4">What We Offer</h2>
          <div className="row">
            <div className="col-md-4 mb-3">
              <div className="feature-box p-4 shadow-sm h-100">
                <h5>Centralized Management</h5>
                <p className="small">Plan, assign, and track all tasks and projects in one system.</p>
              </div>
            </div>
            <div className="col-md-4 mb-3">
              <div className="feature-box p-4 shadow-sm h-100">
                <h5>Team Visibility</h5>
                <p className="small">See who’s working on what, manage workloads, and avoid burnout.</p>
              </div>
            </div>
            <div className="col-md-4 mb-3">
              <div className="feature-box p-4 shadow-sm h-100">
                <h5>Collaboration</h5>
                <p className="small">Keep everyone aligned and make sure no task falls through the cracks.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container py-5 text-center">
        <h2 className="fw-bold mb-3">Join Us</h2>
        <p className="mb-4">Ready to make your workday simple and productive?</p>
        <Link to="/register" className="btn btn-primary px-4 py-2">Get Started</Link>
      </section>

      <Footer />
    </>
  );
};

export default About;
