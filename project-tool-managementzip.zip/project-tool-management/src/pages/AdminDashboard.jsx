import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from '../api/javaaxios';
import { FaUserShield, FaChartBar, FaSignOutAlt } from 'react-icons/fa';
import { Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../styles/admin.css';

ChartJS.register(ArcElement, Tooltip, Legend);

const AdminDashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [adminName, setAdminName] = useState('Admin'); 
  const [dashboardData, setDashboardData] = useState({
    projects: [],
    totalProjects: 0,
    completedProjects: 0,
    pendingTasks: 0,
    inProgressProjects: 0
  });
  const [loading, setLoading] = useState(true);

  const fetchProjectStatus = useCallback(async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const payload = JSON.parse(atob(token.split('.')[1]));
      setAdminName(payload.unique_name || 'Manager');
      if (!token) {
        navigate('/login');
        return;
      }

      const response = await axios.get('admin/project-status-summary', {
        headers: { Authorization: `Bearer ${token}` }
      });

      const data = response.data;
      setDashboardData({
        projects: data.projects || data,
        totalProjects: data.totalProjects || data.length || 0,
        completedProjects: data.completedProjects || 
                         data.filter(p => p.status === 'COMPLETED').length || 0,
        pendingTasks: data.pendingTasks || 
                    data.reduce((sum, p) => sum + (p.pendingCount || 0), 0) || 0,
        inProgressProjects: data.inProgressProjects || 
                          data.filter(p => p.status === 'IN_PROGRESS').length || 0
      });

    } catch (error) {
      console.error('API Error:', {
        message: error.message,
        url: error.config?.url,
        status: error.response?.status
      });

      if (error.response?.status === 401) {
        handleLogout();
        toast.error('Session expired. Please login again.');
      } else if (error.response?.status === 404) {
        toast.error('Endpoint not found. Check backend configuration.');
      } else {
        toast.error('Failed to load dashboard data');
      }
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    fetchProjectStatus();
  }, [fetchProjectStatus]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    navigate('/login');
    toast.info('Logged out successfully');
  };

  // Chart configuration
  const chartData = {
    labels: ['Completed', 'In Progress', 'Pending'],
    datasets: [{
      data: [
        dashboardData.completedProjects,
        dashboardData.inProgressProjects,
        dashboardData.pendingTasks
      ],
      backgroundColor: ['#58A0C8', '#0F828C', '#7A7A73'],
      borderWidth: 1
    }]
  };

  return (
    <div className="dashboard-container">
      <ToastContainer position="top-right" autoClose={3000} />
      
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <FaUserShield className="admin-icon" />
          <h4>{adminName}</h4>
        </div>

        <div className="sidebar-menu">
          <div className={`menu-item ${location.pathname.includes('admin') ? 'active' : ''}`}>
            <FaChartBar className="menu-icon" />
            <span>Project Summary</span>
          </div>
        </div>

        <div className="logout-btn" onClick={handleLogout}>
          <FaSignOutAlt className="logout-icon" />
          <span>Logout</span>
        </div>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        <div className="content-header">
          <h2>Project Analytics</h2>
          <button className="mobile-logout-btn" onClick={handleLogout}>
            <FaSignOutAlt />
          </button>
        </div>

        {/* Stats Cards */}
        <div className="stats-grid">
          <div className="stat-card total-projects">
            <h3>Total Projects</h3>
            <p>{loading ? '-' : dashboardData.totalProjects}</p>
          </div>
          <div className="stat-card completed">
            <h3>Completed</h3>
            <p>{loading ? '-' : dashboardData.completedProjects}</p>
          </div>
          <div className="stat-card pending">
            <h3>Pending Tasks</h3>
            <p>{loading ? '-' : dashboardData.pendingTasks}</p>
          </div>
          <div className="stat-card in-progress">
            <h3>In Progress</h3>
            <p>{loading ? '-' : dashboardData.inProgressProjects}</p>
          </div>
        </div>

        {/* Chart Section */}
        <div className="chart-section">
          <h3>Project Status Distribution</h3>
          <div className="chart-container">
            {loading ? (
              <div className="spinner-container">
                <div className="spinner-border text-primary" role="status"></div>
              </div>
            ) : (
              <Pie 
                data={chartData} 
                options={{ 
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'bottom'
                    }
                  }
                }} 
              />
            )}
          </div>
        </div>

        {/* Projects Table */}
        <div className="table-section">
          <h3>Project Details</h3>
          <div className="table-responsive">
            <table className="projects-table">
              <thead>
                <tr>
                  <th>Project ID</th>
                  <th>Status</th>
                  <th>Pending Tasks</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan="3" className="loading-row">
                      Loading data...
                    </td>
                  </tr>
                ) : dashboardData.projects.length > 0 ? (
                  dashboardData.projects.map((project, index) => (
                    <tr key={index}>
                      <td>{project.projectId}</td>
                      <td>
                        <span className={`status-badge ${
                          project.status === 'COMPLETED' ? 'completed' :
                          project.status === 'IN_PROGRESS' ? 'in-progress' : 'planned'
                        }`}>
                          {project.status}
                        </span>
                      </td>
                      <td>
                        <span className="task-count">
                          {project.pendingTaskCount || 0}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="3" className="no-data">
                      No projects found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;