import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import javaaxios from '../api/javaaxios';

const AssignTasks = () => {
  const [taskName, setTaskName] = useState('');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [status, setStatus] = useState('PENDING');
  const [assignee, setAssignee] = useState('');
  const [createdBy, setCreatedBy] = useState('');
  const [projectId, setProjectId] = useState('');
  const [tasks, setTasks] = useState([]);

  const handleAddTask = async (e) => {
    e.preventDefault();

    if (!taskName || !description || !deadline || !status || !assignee || !createdBy || !projectId) {
      alert('Please fill all fields.');
      return;
    }

    const taskData = {
      title: taskName,
      description,
      deadline,
      status,
      created_By_Manager_id: { id: createdBy },
    };

    try {
      const createResponse = await javaaxios.post(
        `http://localhost:8081/api/tasks/addTask?projectId=${projectId}`,
        taskData
      );

      const createdTask = createResponse.data;
      const taskId = createdTask.id;

      await javaaxios.put(
        `http://localhost:8081/api/tasks/assignTask?taskId=${taskId}&employeeId=${assignee}`
      );

      setTasks([...tasks, { ...createdTask, assignedTo: assignee, projectId }]);

      // Reset
      setTaskName('');
      setDescription('');
      setDeadline('');
      setStatus('PENDING');
      setAssignee('');
      setCreatedBy('');
      setProjectId('');
    } catch (error) {
      console.error('Error saving or assigning task:', error);
      alert('Failed to save or assign task.');
    }
  };

  return (
    <div className="container">
      <h3 className="mt-4">Assign Task</h3>
      <form onSubmit={handleAddTask} className="mb-4">
        <div className="row mb-3">
          <div className="col-md-4">
            <label className="form-label">Task Name</label>
            <input type="text" className="form-control" value={taskName} onChange={(e) => setTaskName(e.target.value)} />
          </div>
          <div className="col-md-4">
            <label className="form-label">Description</label>
            <input type="text" className="form-control" value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div className="col-md-4">
            <label className="form-label">Deadline</label>
            <input type="date" className="form-control" value={deadline} onChange={(e) => setDeadline(e.target.value)} />
          </div>
        </div>

        <div className="row mb-3">
          <div className="col-md-3">
            <label className="form-label">Status</label>
            <select className="form-control" value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="PENDING">Pending</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="COMPLETED">Completed</option>
            </select>
          </div>
          <div className="col-md-3">
            <label className="form-label">Assign To (Employee ID)</label>
            <input type="text" className="form-control" value={assignee} onChange={(e) => setAssignee(e.target.value)} />
          </div>
          <div className="col-md-3">
            <label className="form-label">Created By (Manager ID)</label>
            <input type="text" className="form-control" value={createdBy} onChange={(e) => setCreatedBy(e.target.value)} />
          </div>
          <div className="col-md-3">
            <label className="form-label">Project ID</label>
            <input type="text" className="form-control" value={projectId} onChange={(e) => setProjectId(e.target.value)} />
          </div>
        </div>

        <button type="submit" className="btn btn-primary">Save Task</button>
      </form>

      <h5>Saved Tasks</h5>
      {tasks.length === 0 ? (
        <p>No tasks added yet.</p>
      ) : (
        <table className="table table-bordered">
          <thead className="table-dark">
            <tr>
              <th>Task Name</th>
              <th>Description</th>
              <th>Deadline</th>
              <th>Status</th>
              {/* <th>Employee ID</th> */}
              {/* <th>Manager ID</th> */}
              {/* <th>Project ID</th> */}
            </tr>
          </thead>
          <tbody>
            {tasks.map((task, index) => (
              <tr key={index}>
                <td>{task.title}</td>
                <td>{task.description}</td>
                <td>{task.deadline}</td>
                <td>
                  <span className={`badge ${
                    task.status === 'COMPLETED' ? 'bg-success' :
                    task.status === 'IN_PROGRESS' ? 'bg-info text-dark' :
                    'bg-warning text-dark'
                  }`}>
                    {task.status.replace('_', ' ')}
                  </span>
                </td>
                {/* <td>{task.assignedTo?.id || assignee}</td> */}
                {/* <td>{task.created_By_Manager_id?.id || createdBy}</td> */}
                {/* <td>{task.project?.id || projectId}</td> */}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default AssignTasks;
