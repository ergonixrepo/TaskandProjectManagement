import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FaUserTie, FaUser, FaUserShield } from 'react-icons/fa'; // You can keep using these icons
import '../styles/chooserole.css';
import Navbar from '../components/Navbar';

const ChooseRole = () => {
  const navigate = useNavigate();

  return (
    <>
    <Navbar/>
    <div className="container d-flex flex-column align-items-center justify-content-center min-vh-100 choose-role-wrapper">
      <h2 className="mb-4 text-dark fw-bold">Select Your Role</h2>

      <div className="d-flex flex-column flex-md-row gap-4 mb-3">
        <button
          className="role-card btn-employee"
          onClick={() => navigate('/login?role=employee')}
        >
          <FaUser className="role-icon mb-2" size={48} />
          <span className="role-text">Employee</span>
        </button>

        <button
          className="role-card btn-manager"
          onClick={() => navigate('/login?role=manager')}
        >
          <FaUserTie className="role-icon mb-2" size={48} />
          <span className="role-text">Manager</span>
        </button>
      </div>

      <div>
        <a href="/login?role=admin" className="admin-link text-muted small">
          Login as Admin
        </a>
      </div>
    </div>
    </>
  );
};

export default ChooseRole;
