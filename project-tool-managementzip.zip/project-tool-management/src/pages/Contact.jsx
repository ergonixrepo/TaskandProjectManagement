import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footers';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/Contact.css';

export default function Contact() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your API call here if needed
    alert('Thank you! We will get back to you soon.');
    setForm({ name: '', email: '', message: '' });
  };

  return (
    <>
      <Navbar />

      <div className="container my-5">
        <div className="row justify-content-center">
          <div className="col-md-8 text-center mb-4">
            <h1 className="fw-bold">Contact Us</h1>
            <p className="lead text-muted">
              Got questions or feedback? We'd love to hear from you.
            </p>
          </div>

          <div className="col-md-8">
            <div className="card p-4 shadow-sm">
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label htmlFor="name" className="form-label fw-semibold">Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    name="name"
                    placeholder="Your name"
                    value={form.name}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-3">
                  <label htmlFor="email" className="form-label fw-semibold">Email</label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    name="email"
                    placeholder="Your email"
                    value={form.email}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="mb-3">
                  <label htmlFor="message" className="form-label fw-semibold">Message</label>
                  <textarea
                    className="form-control"
                    id="message"
                    name="message"
                    placeholder="Your message"
                    rows="5"
                    value={form.message}
                    onChange={handleChange}
                    required
                  ></textarea>
                </div>

                <button type="submit" className="btn btn-send w-100">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
