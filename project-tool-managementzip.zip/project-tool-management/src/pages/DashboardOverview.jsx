import React, { useState } from 'react';
import axios from '../api/javaaxios';
import {
  FaUsers,
  FaProjectDiagram,
  FaTasks,
  FaBell,
  FaCogs,
  FaEnvelope
} from 'react-icons/fa';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const DashboardOverview = () => {
  
  const [isSending, setIsSending] = useState(false);

  // Define dashboardItems inside the component
  const dashboardItems = [
    {
      title: 'Team',
      icon: <FaUsers className="text-primary" size={30} />,
      description: 'create team',
    },
    {
      title: 'Projects',
      icon: <FaProjectDiagram className="text-success" size={30} />,
      description: 'Add Projects',

    },
    {
      title: 'Tasks',
      icon: <FaTasks className="text-info" size={30} />,
      description: 'Assign Tasks',
    },
    {
      title: 'Notifications',
      icon: <FaBell className="text-warning" size={30} />,
      description: 'Alerts',
    },
    {
      title: 'Settings',
      icon: <FaCogs className="text-secondary" size={30} />,
      count: '',
      description: 'Manage Preferences',
    },
  ];

  const sendDeadlineReminders = async () => {
    setIsSending(true);
    try {
      const response = await axios.get('/email/sendReminder');
      toast.success(`Sent ${response.data.count} reminders successfully!`);
    } catch (error) {
      toast.error('Failed to send reminders: ' + (error.response?.data?.message || error.message));
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="container my-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Dashboard Overview</h2>
        <button
          onClick={sendDeadlineReminders}
          disabled={isSending}
          className="btn btn-primary"
        >
          <FaEnvelope className="me-2" />
          {isSending ? 'Sending...' : 'Send Deadline Reminders'}
        </button>
      </div>

      <div className="row g-4">
        {dashboardItems.map((item, index) => (
          <div className="col-md-6 col-lg-4" key={index}>
            <div className="card shadow-sm h-100">
              <div className="card-body d-flex align-items-center">
                <div className="me-3">{item.icon}</div>
                <div>
                  <h5 className="card-title mb-1">{item.title}</h5>
                  <p className="card-text text-muted mb-1">{item.description}</p>
                  {item.count && (
                    <h4 className="fw-bold text-dark mb-0">{item.count}</h4>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <ToastContainer position="bottom-right" autoClose={5000} />
    </div>
  );
};

export default DashboardOverview;
