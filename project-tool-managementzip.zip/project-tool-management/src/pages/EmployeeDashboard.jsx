import React, { useEffect, useState } from 'react';
import { FaUser, FaTachometerAlt, FaTasks, FaBell, FaClock, FaSignOutAlt } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/global.css';
import axios from '../api/dotnetaxios';
import MyTasks from './MyTasks';
import { jwtDecode } from "jwt-decode"; // ✅ Correct way with named export
import TimeTracker from "./TimeTracker";
const EmployeeDashboard = () => {
   const [employeeId, setEmployeeId] = useState(null);
  const [activePage, setActivePage] = useState('dashboard');
  const [notifications, setNotifications] = useState([]);
  const [error, setError] = useState('');
  const [employeeName, setEmployeeName] = useState('Employee'); // Default value

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token && !localStorage.getItem("employeeId")) {
      try {
        const decoded = jwtDecode(token);
        const empId = decoded.nameid;
        const empName = decoded.unique_name || decoded.name || 'Employee';
        if (empId) {
          localStorage.setItem("employeeId", empId);
          setEmployeeId(empId); // Optional: if you're using it in state
          console.log("✅ Stored employeeId:", empId);
        } else {
          console.warn("❌ Employee ID not found in token.");
        }
        
         setEmployeeName(empName);
        
      
      } catch (err) {
        console.error("Failed to decode token:", err);
      }
    }
  }, []);

  // ✅ STEP 2: Confirm it's available later
  useEffect(() => {
    const id = localStorage.getItem("employeeId");
    console.log("🎯 Employee ID from localStorage in Dashboard:", id);
    setEmployeeId(id); // Optional, if using in component
  }, []);
  useEffect(() => {
    const role = localStorage.getItem('role');
    if (role !== 'employee') {
      alert('Unauthorized access. Only employees can view this page.');
      window.location.href = '/login';
    }
  }, []);

  useEffect(() => {
    if (activePage === 'notifications') {
      fetchNotifications();
    }
  }, [activePage]);
const fetchNotifications = async () => {
  try {
    const response = await axios.get(`/notifications?userId=${employeeId}`);
    setNotifications(response.data.map(n => ({
      id: n.id,
      message: n.message,
      isRead: n.isRead,
      createdAt: new Date(n.createdAt).toLocaleString(),
      userId: n.userId
    })));
  } catch (err) {
    console.error("Notification error:", {
      status: err.response?.status,
      data: err.response?.data
    });
    setError(err.response?.data?.message || 'Failed to load notifications');
  }
};

const markAsRead = async (id) => {
  try {
    await axios.post(`/notifications/${id}/read`);
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, isRead: true } : n)
    );
  } catch (err) {
    console.error("Mark as read error:", err.response?.data);
    setError(err.response?.data?.message || 'Failed to mark as read');
  }
};


  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('employeeId');
    window.location.href = '/login';
  };

  const renderContent = () => {
    switch (activePage) {
      case 'dashboard':
        return (
          <>
            <h2 className="mb-4">Welcome, EmployeeDashboard</h2>
            <div className="row g-4 mb-4">
              <div className="col-md-3">
                <div className="card border-start border-primary shadow-sm">
                  <div className="card-body">
                    <h6 className="text-muted"> Tasks</h6>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card border-start border-warning shadow-sm">
                  <div className="card-body">
                    <h6 className="text-muted">Notification</h6>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card border-start border-success shadow-sm">
                  <div className="card-body">
                    <h6 className="text-muted">Settings</h6>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card border-start border-danger shadow-sm">
                  <div className="card-body">
                    <h6 className="text-muted">TimeTracker</h6>
                  </div>
                </div>
              </div>
            </div>
          </>
        );
      case 'myTasks':
        return <MyTasks employeeId={employeeId} />;

      case 'notifications':
        return (
          <>
            <h4>Your Notifications</h4>
            {error && <p className="text-danger">{error}</p>}
            {notifications.length === 0 ? (
              <p>No notifications yet.</p>
            ) : (
              <ul className="list-group">
                {notifications.map((n) => (
                  <li
                    key={n.id}
                    className={`list-group-item d-flex justify-content-between align-items-center ${n.isRead ? 'list-group-item-secondary' : ''}`}
                  >
                    <div>
                      {n.message} <br />
                      <small className="text-muted">{new Date(n.createdAt).toLocaleString()}</small>
                    </div>
                    {!n.isRead && (
                      <button
                        className="btn btn-sm btn-outline-success"
                        onClick={() => markAsRead(n.id)}
                      >
                        Mark as Read
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </>
        );
     case 'timetracker':
        return <TimeTracker employeeId={employeeId} />;

      default:
        return null;
    }
  };

  return (
    <div className="d-flex flex-row" style={{ height: '100vh' }}>
      {/* Sidebar */}
      <aside className=" text-white p-3 d-flex flex-column" style={{ width: '250px',backgroundColor: 'rgb(42 29 56)'}}>
        <div className="d-flex align-items-center mb-4">
          <FaUser size={24} className="me-2" />
          <h4 className="mb-0">{employeeName}</h4> 
        </div>
        <ul className="list-unstyled flex-grow-1">
          {[ 
            { key: 'dashboard', label: 'Dashboard', icon: <FaTachometerAlt /> },
            { key: 'myTasks', label: 'My Tasks', icon: <FaTasks /> },
            { key: 'notifications', label: 'Notifications', icon: <FaBell /> },
            { key: 'timetracker', label: 'Time Tracker', icon: <FaClock /> },
          ].map((item) => (
            <li
              key={item.key}
              className={`py-2 px-2 rounded ${activePage === item.key ? 'bg-secondary' : ''}`}
              onClick={() => setActivePage(item.key)}
              style={{ cursor: 'pointer' }}
            >
              {item.icon} <span className="ms-2">{item.label}</span>
            </li>
          ))}
        </ul>
        <div
          className="text-danger py-2 px-2 rounded"
          style={{ cursor: 'pointer' }}
          onClick={handleLogout}
        >
          <FaSignOutAlt className="me-2" /> Logout
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow-1 p-4 overflow-auto">
        <div className="d-flex justify-content-end">
          <button className="btn btn-outline-danger mb-3" onClick={handleLogout}>
            Logout
          </button>
        </div>
        {renderContent()}
      </main>
    </div>
  );
};

export default EmployeeDashboard;