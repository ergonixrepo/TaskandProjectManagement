import React, { useState } from 'react';
import axios from '../api/dotnetaxios';
import { useNavigate, Link, useLocation } from 'react-router-dom'; // ✅ Added useLocation!
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/Login.css';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const location = useLocation(); // ✅ Added this!

  // const handleLogin = async (e) => {
  //   e.preventDefault();

  //   try {
  //     // ✅ Get ?role= from URL
  //     const params = new URLSearchParams(location.search);
  //     const selectedRole = params.get('role');

  //     const response = await axios.post('/Auth/Login', {
  //       email: email,
  //       password: password,
  //     });

  //     const token = response.data.token;
  //     const apiRole = response.data.user.role.toLowerCase();

  //     localStorage.setItem('token', token);
  //     localStorage.setItem('role', apiRole); // ✅ store it for ProtectedRoute
      
  //     // ✅ OPTIONAL: check mismatch
  //     if (selectedRole && apiRole !== selectedRole) {
  //       alert(`Role mismatch! You selected ${selectedRole} but your account is ${apiRole}.`);
  //       return;
  //     }

  //     // ✅ Navigate based on **API role**
  //     navigate(`/${apiRole}-dashboard`);
  //   } catch (error) {
  //     console.error('Login failed:', error);
  //     alert('Invalid credentials. Please try again.');
  //   }
  // };
const handleLogin = async (e) => {
  e.preventDefault();

  try {
    const params = new URLSearchParams(location.search);
    const selectedRole = params.get('role');

    const response = await axios.post('/Auth/Login', {
      email: email,
      password: password,
    }, {
      headers: {
        'Content-Type': 'application/json'
      }
    });

    const token = response.data.token;
    const apiRole = response.data.user.role.toLowerCase();

    localStorage.setItem('token', token);
    localStorage.setItem('role', apiRole);
    
    if (selectedRole && apiRole !== selectedRole) {
      alert(`Role mismatch! You selected ${selectedRole} but your account is ${apiRole}.`);
      return;
    }

    navigate(`/${apiRole}-dashboard`);
  } catch (error) {
    console.error('Login error:', {
      status: error.response?.status,
      data: error.response?.data,
      message: error.message
    });
    
    if (error.code === 'ERR_NETWORK') {
      alert('Cannot connect to server. Please check your connection and try again.');
    } else if (error.response?.status === 401) {
      alert('Invalid credentials. Please try again.');
    } else {
      alert('Login failed. Please try again later.');
    }
  }
};
  return (
    <div className="container d-flex align-items-center justify-content-center min-vh-100">
<div className="card login-card" style={{ maxWidth: "350px" }}>
        <h2 className="text-center mb-4">Login</h2>
        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label htmlFor="email" className="form-label fw-semibold">
              Email address
            </label>
            <input
              type="email"
              className="form-control"
              id="email"
              placeholder="Enter your email"
              value={email}
              required
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="mb-4">
            <label htmlFor="password" className="form-label fw-semibold">
              Password
            </label>
            <input
              type="password"
              className="form-control"
              id="password"
              placeholder="Enter your password"
              value={password}
              required
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button type="submit" className="btn btn-primary w-100 mb-2">
            Login
          </button>

          <div className="text-center mt-3">
            <Link to="/choose-role" className="text-decoration-none">
              &larr; Back to Role Selection
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
