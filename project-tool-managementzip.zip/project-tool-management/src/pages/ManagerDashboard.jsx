// import React, { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import '../styles/global.css';
// import axios from '../api/dotnetaxios';
// import AssignTasks from './AssignTasks';
// import Projects from './Projects'; 
// import TeamManagement from './TeamManagement';
// import ManagerSettings from './ManagerSettings';
// import DashboardOverview from './DashboardOverview';
// import {
//   FaUserTie,
//   FaTachometerAlt,
//   FaTasks,
//   FaFolder,
//   FaUsers,
//   FaBell,
//   FaChartPie,
//   FaCog,
//   FaSignOutAlt,
//   FaSpinner
// } from 'react-icons/fa';

// const ManagerDashboard = () => {
//   const navigate = useNavigate(); 
//   const [activePage, setActivePage] = useState('dashboard');
//   const [employeeId, setEmployeeId] = useState('');
//   const [notificationText, setNotificationText] = useState('');
//   const [notifications, setNotifications] = useState([]);
//   const [managerName, setManagerName] = useState('Manager');
//   const [isLoading, setIsLoading] = useState(false);
//   const [sending, setSending] = useState(false);
// const [notificationForm, setNotificationForm] = useState({
//   employeeId: '',
//   message: ''
// });
//   useEffect(() => {
//     const token = localStorage.getItem('token');
//     if (token) {
//       try {
//         const payload = JSON.parse(atob(token.split('.')[1]));
//         setManagerName(payload.unique_name || 'Manager');
//       } catch (e) {
//         console.error('Error parsing token:', e);
//       }
//     }
//   }, []);

//   const fetchNotifications = async () => {
//     setIsLoading(true);
//     try {
//       const response = await axios.get('/notifications/sent');
//       setNotifications(response.data);
//     } catch (error) {
//       console.error('Fetch notifications error:', error);
//       alert(error.message || 'Failed to fetch notifications');
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const sendNotification = async (e) => {
//   e.preventDefault();
  
//   if (!notificationForm.employeeId) {
//     alert('Please enter an employee ID');
//     return;
//   }
  
//   if (!notificationForm.message.trim()) {
//     alert('Please enter a notification message');
//     return;
//   }

//   try {
//     await axios.post('/notifications', {
//       receiverId: Number(notificationForm.employeeId),
//       message: notificationForm.message
//     });
//     alert('Notification sent successfully!');
//     setNotificationForm({ employeeId: '', message: '' });
//   } catch (error) {
//     console.error('Send notification error:', error);
//     alert(error.response?.data?.message || 'Failed to send notification');
//   }
// };

//   useEffect(() => {
//     if (activePage === 'notifications') {
//       fetchNotifications();
//     }
//   }, [activePage]);

//   const renderContent = () => {
//     switch (activePage) {
//       case 'dashboard':
//         return <DashboardOverview />;
//       case 'assignTasks':
//         return <AssignTasks />;
//       case 'projects':
//         return <Projects />;
//       case 'team':
//         return <TeamManagement />;
//       case 'notifications':
//   return (
//     <div className="notifications-container">
//       {/* Send Notification Card */}
//       <div className="card mb-4">
//         <div className="card-header bg-primary text-white">
//           <h3 className="mb-0">Send Notification</h3>
//         </div>
//         <div className="card-body">
//           <form onSubmit={sendNotification}>
//             <div className="mb-3">
//               <label htmlFor="employeeId" className="form-label">Employee ID</label>
//               <input
//                 type="number"
//                 id="employeeId"
//                 className="form-control"
//                 placeholder="Enter Employee ID"
//                 value={employeeId}
//                 onChange={(e) => setEmployeeId(e.target.value)}
//                 required
//                 min="1"
//               />
//               <div className="form-text">
//                 Enter the ID of the employee you want to notify
//               </div>
//             </div>
//             <div className="mb-3">
//               <label htmlFor="notificationText" className="form-label">Message</label>
//               <textarea
//                 id="notificationText"
//                 className="form-control"
//                 placeholder="Enter your message here..."
//                 rows={4}
//                 value={notificationText}
//                 onChange={(e) => setNotificationText(e.target.value)}
//                 required
//                 maxLength="500"
//               />
//               <div className="form-text d-flex justify-content-between">
//                 <span>Max 500 characters</span>
//                 <span>{notificationText.length}/500</span>
//               </div>
//             </div>
//             <div className="d-flex justify-content-end">
//               <button 
//                 type="submit" 
//                 className="btn btn-primary px-4"
//                 disabled={sending}
//               >
//                 {sending ? (
//                   <>
//                     <FaSpinner className="fa-spin me-2" />
//                     Sending...
//                   </>
//                 ) : (
//                   <>
//                     <FaBell className="me-2" />
//                     Send Notification
//                   </>
//                 )}
//               </button>
//             </div>
//           </form>
//         </div>
//       </div>

//       {/* Sent Notifications Card */}
//       <div className="card">
//         <div className="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
//           <h3 className="mb-0">Sent Notifications</h3>
//           <button 
//             className="btn btn-sm btn-light"
//             onClick={fetchNotifications}
//             disabled={isLoading}
//           >
//             {isLoading ? (
//               <FaSpinner className="fa-spin" />
//             ) : (
//               <FaChartPie />
//             )}
//           </button>
//         </div>
//         <div className="card-body p-0">
//           {isLoading ? (
//             <div className="text-center py-4">
//               <FaSpinner className="fa-spin me-2" />
//               Loading notifications...
//             </div>
//           ) : (
//             <div className="table-responsive">
//               <table className="table table-hover mb-0">
//                 <thead className="table-light">
//                   <tr>
//                     <th width="25%">Employee</th>
//                     <th width="45%">Message</th>
//                     <th width="20%">Date Sent</th>
//                     <th width="10%">Status</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {notifications.length > 0 ? (
//                     notifications.map((note) => (
//                       <tr 
//                         key={note.id} 
//                         className={note.isRead ? '' : 'unread-notification'}
//                         onClick={() => markAsRead(note.id)}
//                         style={{ cursor: 'pointer' }}
//                       >
//                         <td>
//                           <div className="d-flex align-items-center">
//                             <div className="avatar-sm bg-light rounded-circle me-2 d-flex align-items-center justify-content-center">
//                               <FaUserTie className="text-muted" />
//                             </div>
//                             <div>
//                               <div className="fw-medium">
//                                 {note.employeeName || note.User?.name || `Employee ${note.receiverId}`}
//                               </div>
//                               <small className="text-muted">ID: {note.receiverId}</small>
//                             </div>
//                           </div>
//                         </td>
//                         <td>
//                           <div className="text-truncate" style={{ maxWidth: '300px' }}>
//                             {note.message}
//                           </div>
//                         </td>
//                         <td>
//                           {new Date(note.createdAt).toLocaleString([], {
//                             year: 'numeric',
//                             month: 'short',
//                             day: 'numeric',
//                             hour: '2-digit',
//                             minute: '2-digit'
//                           })}
//                         </td>
//                         <td className="text-center">
//                           {note.isRead ? (
//                             <span className="badge bg-success">Read</span>
//                           ) : (
//                             <span className="badge bg-warning text-dark">Unread</span>
//                           )}
//                         </td>
//                       </tr>
//                     ))
//                   ) : (
//                     <tr>
//                       <td colSpan="4" className="text-center py-4">
//                         <div className="d-flex flex-column align-items-center">
//                           <FaBell className="text-muted mb-2" size={24} />
//                           <span>No notifications sent yet</span>
//                           <small className="text-muted">Notifications you send will appear here</small>
//                         </div>
//                       </td>
//                     </tr>
//                   )}
//                 </tbody>
//               </table>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
//       case 'settings':
//         return <ManagerSettings />;
//       default:
//         return null;
//     }
//   };

//   const handleLogout = () => {
//     localStorage.removeItem('token');
//     localStorage.removeItem('role');
//     navigate('/login');
//   };

//   return (
//     <div className="d-flex flex-row" style={{ height: '100vh' }}>
//       {/* Sidebar */}
//       <aside className="text-white p-3 d-flex flex-column" style={{ width: '250px', backgroundColor: 'rgb(42 29 56)'}}>
//         <div className="d-flex align-items-center mb-4">
//           <FaUserTie size={24} className="me-2" />
//           <h4 className="mb-0">{managerName}</h4>
//         </div>
//         <ul className="list-unstyled flex-grow-1">
//           {[
//             { key: 'dashboard', label: 'Dashboard', icon: <FaTachometerAlt /> },
//             { key: 'assignTasks', label: 'Assign Tasks', icon: <FaTasks /> },
//             { key: 'projects', label: 'Projects', icon: <FaFolder /> },
//             { key: 'team', label: 'Team', icon: <FaUsers /> },
//             { key: 'notifications', label: 'Notifications', icon: <FaBell /> },
//             { key: 'settings', label: 'Settings', icon: <FaCog /> },
//           ].map((item) => (
//             <li
//               key={item.key}
//               className={`py-2 px-2 rounded ${activePage === item.key ? 'bg-secondary' : ''}`}
//               onClick={() => setActivePage(item.key)}
//               style={{ cursor: 'pointer' }}
//             >
//               {item.icon} <span className="ms-2">{item.label}</span>
//             </li>
//           ))}
//         </ul>
//         <div
//           className="text-danger py-2 px-2 rounded"
//           style={{ cursor: 'pointer' }}
//           onClick={handleLogout}
//         >
//           <FaSignOutAlt className="me-2" /> Logout
//         </div>
//       </aside>

//       {/* Main Content */}
//       <main className="flex-grow-1 p-4 overflow-auto">
//         <div className="d-flex justify-content-end">
//           <button className="btn btn-outline-danger mb-3" onClick={handleLogout}>
//             Logout
//           </button>
//         </div>
//         {renderContent()}
//       </main>
//     </div>
//   );
// };

// export default ManagerDashboard;
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/global.css';
import axios from '../api/dotnetaxios';
import AssignTasks from './AssignTasks';
import Projects from './Projects'; 
import TeamManagement from './TeamManagement';
import ManagerSettings from './ManagerSettings';
import DashboardOverview from './DashboardOverview';
import {
  FaUserTie,
  FaTachometerAlt,
  FaTasks,
  FaFolder,
  FaUsers,
  FaBell,
  FaChartPie,
  FaCog,
  FaSignOutAlt,
  FaSpinner
} from 'react-icons/fa';

const ManagerDashboard = () => {
  const navigate = useNavigate(); 
  const [activePage, setActivePage] = useState('dashboard');
  const [notificationForm, setNotificationForm] = useState({
    employeeId: '',
    message: ''
  });
  const [managerName, setManagerName] = useState('Manager');
  //const [isLoading, setIsLoading] = useState(false);
  const [sending, setSending] = useState(false); // Added sending state
  // const [ setError] = useState(null);
const [ setNotifications] = useState([]);
const [setIsLoading] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        setManagerName(payload.unique_name || 'Manager');
      } catch (e) {
        console.error('Error parsing token:', e);
      }
    }
  }, []);

  const fetchNotifications = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get('/Notifications');
      setNotifications(response.data);
    } catch (error) {
      console.error('Fetch notifications error:', error);
      alert(error.message || 'Failed to fetch notifications');
    } finally {
      setIsLoading(false);
    }
  };
//  // ✅ Define fetchNotifications
//   const fetchNotifications = async () => {
//   setIsLoading(true);
//   const managerId = localStorage.getItem('managerId');
//   const token = localStorage.getItem('token');

//   try {
//     const response = await axios.get(`/Notifications/sent?managerId=${managerId}`, {
//       headers: {
//         'Authorization': `Bearer ${token}`,
//         'Content-Type': 'application/json'
//       }
//     });

//     setNotifications(response.data);
//   } catch (error) {
//     console.error('Failed to fetch notifications:', error);
//   } finally {
//     setIsLoading(false);
//   }
// };

//   // ✅ useEffect to load notifications
//   useEffect(() => {
//     if (activePage === 'notifications') {
//       fetchNotifications();
//     }
//   }, [activePage]);


// const markAsRead = async (notificationId) => {
//   const token = localStorage.getItem('token');

//   try {
//     await axios.put(`/Notifications/${notificationId}/mark-read`, {}, {
//       headers: {
//         'Authorization': `Bearer ${token}`,
//         'Content-Type': 'application/json'
//       }
//     });

//     // Refresh notifications after marking as read
//     fetchNotifications();
//   } catch (error) {
//     console.error('Failed to mark notification as read:', error);
//   }
// };

const sendNotification = async (e) => {
  e.preventDefault();
  
  // Validate inputs
  const employeeId = Number(notificationForm.employeeId);
  if (isNaN(employeeId) || employeeId <= 0) {
    alert('Please enter a valid employee ID');
    return;
  }
  
  if (!notificationForm.message.trim()) {
    alert('Please enter a notification message');
    return;
  }

  setSending(true);
  try {
    // Get current user ID from token
    const token = localStorage.getItem('token');
    const payload = JSON.parse(atob(token.split('.')[1]));
    const currentUserId = payload.nameid; // Adjust based on your JWT structure

    const response = await axios.post('/Notifications', {
      userId: employeeId,       // Recipient ID
      createdBy: currentUserId, // Sender ID
      message: notificationForm.message.trim()
    }, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    console.log('Success:', response.data);
    alert('Notification sent successfully!');
    setNotificationForm({ employeeId: '', message: '' });
    await fetchNotifications();
  } catch (error) {
    console.error('Detailed error:', {
      request: error.config,
      response: error.response?.data
    });
    
    const errorMsg = error.response?.data?.title || 
                   error.response?.data?.detail ||
                   '';
    alert(`Error: ${errorMsg}`);
  } finally {
    setSending(false);
  }
};
  useEffect(() => {
    if (activePage === 'notifications') {
      fetchNotifications();
    }
  }, [activePage]);

  const renderContent = () => {
    switch (activePage) {
      case 'dashboard':
        return <DashboardOverview />;
      case 'assignTasks':
        return <AssignTasks />;
      case 'projects':
        return <Projects />;
      case 'team':
        return <TeamManagement />;
      case 'notifications':
        return (
          <div className="notifications-container">
            {/* Send Notification Card */}
            <div className="card mb-4">
              <div className="card-header bg-primary text-white">
                <h3 className="mb-0">Send Notification</h3>
              </div>
              <div className="card-body">
                <form onSubmit={sendNotification}>
                  <div className="mb-3">
                    <label htmlFor="employeeId" className="form-label">Employee ID</label>
                    <input
                      type="number"
                      id="employeeId"
                      className="form-control"
                      placeholder="Enter Employee ID"
                      value={notificationForm.employeeId}
                      onChange={(e) => setNotificationForm({...notificationForm, employeeId: e.target.value})}
                      required
                      min="1"
                    />
                    <div className="form-text">
                      Enter the ID of the employee you want to notify
                    </div>
                  </div>
                  <div className="mb-3">
                    <label htmlFor="notificationText" className="form-label">Message</label>
                    <textarea
                      id="notificationText"
                      className="form-control"
                      placeholder="Enter your message here..."
                      rows={4}
                      value={notificationForm.message}
                      onChange={(e) => setNotificationForm({...notificationForm, message: e.target.value})}
                      required
                      maxLength="500"
                    />
                    <div className="form-text d-flex justify-content-between">
                      <span>Max 500 characters</span>
                      <span>{notificationForm.message.length}/500</span>
                    </div>
                  </div>
                  <div className="d-flex justify-content-end">
                    <button 
                      type="submit" 
                      className="btn btn-primary px-4"
                      disabled={sending}
                    >
                      {sending ? (
                        <>
                          <FaSpinner className="fa-spin me-2" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <FaBell className="me-2" />
                          Send Notification
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>

            {/* Sent Notifications Card */}
            {/* <div className="card">
              <div className="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                <h3 className="mb-0">Sent Notifications</h3>
                <button 
                  className="btn btn-sm btn-light"
                  onClick={fetchNotifications}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <FaSpinner className="fa-spin" />
                  ) : (
                    <FaChartPie />
                  )}
                </button>
              </div>
              <div className="card-body p-0">
                {isLoading ? (
                  <div className="text-center py-4">
                    <FaSpinner className="fa-spin me-2" />
                    Loading notifications...
                  </div>
                ) : (
                  <div className="table-responsive">
                    <table className="table table-hover mb-0">
                      <thead className="table-light">
                        <tr>
                          <th width="25%">Employee</th>
                          <th width="45%">Message</th>
                          <th width="20%">Date Sent</th>
                          <th width="10%">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {notifications.length > 0 ? (
                          notifications.map((note) => (
                            <tr 
                              key={note.id} 
                              className={note.isRead ? '' : 'unread-notification'}
                              onClick={() => markAsRead(note.id)}
                              style={{ cursor: 'pointer' }}
                            >
                              <td>
                                <div className="d-flex align-items-center">
                                  <div className="avatar-sm bg-light rounded-circle me-2 d-flex align-items-center justify-content-center">
                                    <FaUserTie className="text-muted" />
                                  </div>
                                  <div>
                                    <div className="fw-medium">
                                      {note.employeeName || note.User?.name || `Employee ${note.receiverId}`}
                                    </div>
                                    <small className="text-muted">ID: {note.receiverId}</small>
                                  </div>
                                </div>
                              </td>
                              <td>
                                <div className="text-truncate" style={{ maxWidth: '300px' }}>
                                  {note.message}
                                </div>
                              </td>
                              <td>
                                {new Date(note.createdAt).toLocaleString([], {
                                  year: 'numeric',
                                  month: 'short',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </td>
                              <td className="text-center">
                                {note.isRead ? (
                                  <span className="badge bg-success">Read</span>
                                ) : (
                                  <span className="badge bg-warning text-dark">Unread</span>
                                )}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan="4" className="text-center py-4">
                              <div className="d-flex flex-column align-items-center">
                                <FaBell className="text-muted mb-2" size={24} />
                                <span>No notifications sent yet</span>
                                <small className="text-muted">Notifications you send will appear here</small>
                              </div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div> */}

          </div>
        );
      case 'settings':
        return <ManagerSettings />;
      default:
        return null;
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    navigate('/login');
  };

  return (
    <div className="d-flex flex-row" style={{ height: '100vh' }}>
      {/* Sidebar */}
      <aside className="text-white p-3 d-flex flex-column" style={{ width: '250px', backgroundColor: 'rgb(42 29 56)'}}>
        <div className="d-flex align-items-center mb-4">
          <FaUserTie size={24} className="me-2" />
          <h4 className="mb-0">{managerName}</h4>
        </div>
        <ul className="list-unstyled flex-grow-1">
          {[
            { key: 'dashboard', label: 'Dashboard', icon: <FaTachometerAlt /> },
            { key: 'assignTasks', label: 'Assign Tasks', icon: <FaTasks /> },
            { key: 'projects', label: 'Projects', icon: <FaFolder /> },
            { key: 'team', label: 'Team', icon: <FaUsers /> },
            { key: 'notifications', label: 'Notifications', icon: <FaBell /> },
            { key: 'settings', label: 'Settings', icon: <FaCog /> },
          ].map((item) => (
            <li
              key={item.key}
              className={`py-2 px-2 rounded ${activePage === item.key ? 'bg-secondary' : ''}`}
              onClick={() => setActivePage(item.key)}
              style={{ cursor: 'pointer' }}
            >
              {item.icon} <span className="ms-2">{item.label}</span>
            </li>
          ))}
        </ul>
        <div
          className="text-danger py-2 px-2 rounded"
          style={{ cursor: 'pointer' }}
          onClick={handleLogout}
        >
          <FaSignOutAlt className="me-2" /> Logout
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow-1 p-4 overflow-auto">
        <div className="d-flex justify-content-end">
          <button className="btn btn-outline-danger mb-3" onClick={handleLogout}>
            Logout
          </button>
        </div>
        {renderContent()}
      </main>
    </div>
  );
};

export default ManagerDashboard;