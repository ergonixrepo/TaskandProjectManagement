import React, { useState } from 'react';

const ManagerSettings = () => {
  const [profile, setProfile] = useState({
    name: 'John Doe',
    email: 'john@example.com',
    phone: '9876543210',
  });

  const [passwords, setPasswords] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const handleProfileChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handlePasswordChange = (e) => {
    setPasswords({ ...passwords, [e.target.name]: e.target.value });
  };

  const updateProfile = () => {
    console.log('Updated Profile:', profile);
    alert('Profile updated successfully.');
  };

  const updatePassword = () => {
    if (passwords.newPassword !== passwords.confirmPassword) {
      alert('New password and confirm password do not match!');
      return;
    }

    console.log('Password updated');
    alert('Password changed successfully.');
    setPasswords({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  return (
    <div className="container mt-4">
      <h3>Settings</h3>

      {/* Profile Info */}
      <div className="card p-3 mb-4">
        <h5>Profile Information</h5>
        <input
          type="text"
          name="name"
          value={profile.name}
          onChange={handleProfileChange}
          placeholder="Full Name"
          className="form-control mb-2"
        />
        <input
          type="email"
          name="email"
          value={profile.email}
          onChange={handleProfileChange}
          placeholder="Email"
          className="form-control mb-2"
        />
        <input
          type="text"
          name="phone"
          value={profile.phone}
          onChange={handleProfileChange}
          placeholder="Phone Number"
          className="form-control mb-2"
        />
        <button className="btn btn-primary" onClick={updateProfile}>
          Save Changes
        </button>
      </div>

      {/* Change Password */}
      <div className="card p-3 mb-4">
        <h5>Change Password</h5>
        <input
          type="password"
          name="currentPassword"
          value={passwords.currentPassword}
          onChange={handlePasswordChange}
          placeholder="Current Password"
          className="form-control mb-2"
        />
        <input
          type="password"
          name="newPassword"
          value={passwords.newPassword}
          onChange={handlePasswordChange}
          placeholder="New Password"
          className="form-control mb-2"
        />
        <input
          type="password"
          name="confirmPassword"
          value={passwords.confirmPassword}
          onChange={handlePasswordChange}
          placeholder="Confirm New Password"
          className="form-control mb-2"
        />
        <button className="btn btn-warning" onClick={updatePassword}>
          Update Password
        </button>
      </div>

      {/* Notification Toggle */}
      <div className="card p-3 mb-4">
        <h5>Notification Preferences</h5>
        <div className="form-check form-switch">
          <input
            className="form-check-input"
            type="checkbox"
            id="notifications"
            checked={notificationsEnabled}
            onChange={() => setNotificationsEnabled(!notificationsEnabled)}
          />
          <label className="form-check-label" htmlFor="notifications">
            {notificationsEnabled ? 'Notifications Enabled' : 'Notifications Disabled'}
          </label>
        </div>
      </div>
    </div>
  );
};

export default ManagerSettings;
