import React, { useState, useEffect } from 'react';
import axios from '../api/javaaxios';

const TaskTimer = ({ taskId, onTimeTracked, initialDuration }) => {
  const [startTime, setStartTime] = useState(null);
  const [duration, setDuration] = useState(initialDuration || null);

  const handleStart = () => {
    setStartTime(new Date());
  };

  const handleEnd = () => {
    if (startTime) {
      const now = new Date();
      const diffMs = now - startTime;
      const diffMinutes = Math.floor(diffMs / 60000);
      const diffSeconds = Math.floor((diffMs % 60000) / 1000);
      const result = `${diffMinutes} min ${diffSeconds} sec`;
      setDuration(result);
      onTimeTracked && onTimeTracked(taskId, result, diffMs);
      setStartTime(null);
    }
  };

  return (
    <div className="d-flex align-items-center">
      <button 
        onClick={handleStart} 
        className="btn btn-sm btn-success me-2"
        disabled={!!startTime}
      >
        Start
      </button>
      <button 
        onClick={handleEnd} 
        className="btn btn-sm btn-danger"
        disabled={!startTime}
      >
        Done
      </button>
      {duration && (
        <span className="ms-2">
          ⏱ <small>{duration}</small>
        </span>
      )}
    </div>
  );
};

const MyTasks = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const employeeId = localStorage.getItem('employeeId');

  // Load time data from localStorage
  const getSavedTimeData = () => {
    const savedData = localStorage.getItem('taskTimeData');
    return savedData ? JSON.parse(savedData) : {};
  };

  // Save time data to localStorage
  const saveTimeData = (data) => {
    localStorage.setItem('taskTimeData', JSON.stringify(data));
  };

  useEffect(() => {
    if (!employeeId) {
      setError('Employee ID not found. Please login again.');
      setLoading(false);
      return;
    }

    const fetchTasks = async () => {
      try {
        const response = await axios.get(`/tasks/getTasksByEmployee?employeeId=${employeeId}`);
        const timeData = getSavedTimeData();
        
        const allTasks = response.data.flatMap(project =>
          project.tasks.map(task => {
            const taskId = task.task_id;
            const savedTime = timeData[taskId] || {};
            
            return {
              ...task,
              id: taskId,
              projectId: project.Project_id,
              timeSpent: savedTime.timeSpent || 0,
              lastDuration: savedTime.lastDuration || null
            };
          })
        );
        
        setTasks(allTasks);
      } catch (err) {
        console.error('Error fetching tasks:', err);
        setError('Failed to fetch tasks. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchTasks();
  }, [employeeId]);

  const handleStatusChange = async (taskId, newStatus) => {
    try {
      const response = await axios.put(`/tasks/updateStatus/${taskId}`, {
        status: newStatus
      });
      setTasks(prevTasks =>
        prevTasks.map(task =>
          task.id === taskId ? { ...task, status: newStatus } : task
        )
      );
      alert(response.data);
    } catch (error) {
      console.error("Error updating status:", error);
      alert(error.response?.data || "Failed to update status.");
    }
  };

  const handleTimeTracked = (taskId, duration, milliseconds) => {
    const timeData = getSavedTimeData();
    
    // Update the time data
    timeData[taskId] = {
      timeSpent: (timeData[taskId]?.timeSpent || 0) + milliseconds,
      lastDuration: duration
    };
    
    // Save to localStorage
    saveTimeData(timeData);
    
    // Update the UI
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId 
          ? { 
              ...task, 
              timeSpent: timeData[taskId].timeSpent,
              lastDuration: duration 
            } 
          : task
      )
    );
  };

  const formatTimeSpent = (milliseconds) => {
    if (!milliseconds) return 'Not tracked';
    const minutes = Math.floor(milliseconds / 60000);
    const seconds = Math.floor((milliseconds % 60000) / 1000);
    return `${minutes} min ${seconds} sec`;
  };

  return (
    <div className="container mt-4">
      <h3 className="mb-3">My Tasks</h3>

      {loading && <p>Loading tasks...</p>}
      {error && <div className="alert alert-danger">{error}</div>}

      {!loading && !error && tasks.length === 0 && (
        <p>No tasks assigned.</p>
      )}

      {!loading && tasks.length > 0 && (
        <table className="table table-bordered table-hover">
          <thead className="table-dark">
            <tr>
              <th>Project ID</th>
              <th>Title</th>
              <th>Status</th>
              <th>Time Tracking</th>
              <th>Total Time</th>
              <th>Deadline</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task) => (
              <tr key={`task-${task.id}`}>
                <td>{task.projectId}</td>
                <td>{task.title || 'Untitled'}</td>
                <td>
                  <select
                    value={task.status}
                    onChange={(e) => handleStatusChange(task.id, e.target.value)}
                    className="form-select form-select-sm"
                  >
                    <option value="PENDING">Pending</option>
                    <option value="IN_PROGRESS">In Progress</option>
                    <option value="COMPLETED">Completed</option>
                  </select>
                </td>
                <td>
                  <TaskTimer 
                    taskId={task.id} 
                    onTimeTracked={handleTimeTracked}
                    initialDuration={task.lastDuration}
                  />
                </td>
                <td>{formatTimeSpent(task.timeSpent)}</td>
                <td>
                  {task.deadline ? new Date(task.deadline).toLocaleDateString() : 'N/A'}
                </td>
                <td>{task.description || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default MyTasks;