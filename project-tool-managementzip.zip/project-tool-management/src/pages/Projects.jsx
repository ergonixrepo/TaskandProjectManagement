import React, { useState } from 'react';
import axios from '../api/javaaxios'; // update this path if needed
import 'bootstrap/dist/css/bootstrap.min.css';

const Projects = () => {
  const [formData, setFormData] = useState({
    projectId: '',
    name: '',
    role: '',
    managerId: '',
    task: '',
    taskName: '',
    status: 'PENDING',
    deadline: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      name: formData.name,
      description: formData.task,
      startDate: new Date().toISOString().split('T')[0], // today's date
      endDate: formData.deadline
    };

    try {
      await axios.post(`/projects/addproject?userId=${formData.managerId}`, payload);
      alert('Project saved successfully!');
      setFormData({
        projectId: '',
        name: '',
        role: '',
        managerId: '',
        task: '',
        taskName: '',
        status: 'PLANNED',
        deadline: ''
      });
    } catch (err) {
      console.error(err);
      alert('Failed to save project');
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Add Project</h2>
      <form onSubmit={handleSubmit}>
        <div className="row mb-3">
          <div className="col">
            <label htmlFor="name" className="form-label">Project Name</label>
            <input type="text" className="form-control" id="name" name="name"
              value={formData.name} onChange={handleChange} required />
          </div>
          <div className="col">
            <label htmlFor="managerId" className="form-label">Manager ID</label>
            <input type="text" className="form-control" id="managerId" name="managerId"
              value={formData.managerId} onChange={handleChange} required />
          </div>
        </div>

        <div className="row mb-3">
          <div className="col">
            <label htmlFor="task" className="form-label">Project Description</label>
            <input type="text" className="form-control" id="task" name="task"
              value={formData.task} onChange={handleChange} required />
          </div>
          <div className="col">
            <label htmlFor="deadline" className="form-label">End Date</label>
            <input type="date" className="form-control" id="deadline" name="deadline"
              value={formData.deadline} onChange={handleChange} required />
          </div>
        </div>

        {/* Optional Fields - Not required for backend but kept for layout consistency */}
        <div className="row mb-3">
          <div className="col">
            <label htmlFor="projectId" className="form-label">Project ID</label>
            <input type="text" className="form-control" id="projectId" name="projectId"
              value={formData.projectId} onChange={handleChange} />
          </div>
          <div className="col">
            <label htmlFor="role" className="form-label">Role</label>
            <input type="text" className="form-control" id="role" name="role"
              value={formData.role} onChange={handleChange} />
          </div>
        </div>

        <div className="row mb-3">
          <div className="col">
            <label htmlFor="taskName" className="form-label">Task Name</label>
            <input type="text" className="form-control" id="taskName" name="taskName"
              value={formData.taskName} onChange={handleChange} />
          </div>
          <div className="col">
            <label className="form-label">Status</label>
            <div className="form-check">
              <input className="form-check-input" type="radio" name="PLANNED" value="PLANNED"
                checked={formData.status === 'PLANNED'} onChange={handleChange} />
              <label className="form-check-label">Assigned</label>
            </div>
            <div className="form-check">
              <input className="form-check-input" type="radio" name=" IN_PROGRESS" value="IN_PROGRESS"
                checked={formData.status === 'inprogress'} onChange={handleChange} />
              <label className="form-check-label">In Progress</label>
            </div>
            <div className="form-check">
              <input className="form-check-input" type="radio" name="COMPLETED" value="COMPLETED"
                checked={formData.status === 'complete'} onChange={handleChange} />
              <label className="form-check-label">Complete</label>
            </div>
          </div>
        </div>

        <button type="submit" className="btn btn-primary">Save Project</button>
      </form>
    </div>
  );
};

export default Projects;
