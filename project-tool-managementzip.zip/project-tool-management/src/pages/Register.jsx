import React, { useState } from 'react';
import axios from '../api/dotnetaxios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

import '../styles/register.css';

export default function Register() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    employee_id: '',
    name: '',
    email: '',
    phonenumber: '',
    gender: '',
    noOfYearsExperience: '',
    password: '',
    role: 'EMPLOYEE',
    jobDesignation: ''
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      // Map camelCase fields to snake_case for backend compatibility
      const payload = {
        employee_id: form.employee_id,
        name: form.name,
        email: form.email,
        phonenumber: form.phonenumber,
        gender: form.gender,
        no_of_years_experience: form.noOfYearsExperience,
        password: form.password,
        role: form.role,
        job_designation: form.jobDesignation
      };

     const response= await axios.post('/Auth/Register', payload);
      if (response.status === 200 || response.status === 201) {
      alert('Registered successfully!');
      // Optionally redirect to login
      navigate('/login');
    } else {
      alert('Unexpected response from server.');
    }
    } catch (err) {
      console.error(err.response?.data || err.message);
      // alert('Registration failed.');
    }
  };

  const handleLoginRedirect = () => {
    navigate('/login');
  };

  return (
    <>
    
<div className="container register-page d-flex align-items-center justify-content-center min-vh-100">
      <div className="card shadow-lg p-4" style={{ width: '600px' }}>
        <h2 className="text-center mb-4">Registration</h2>
        <p className="text-center text-muted mb-4">
          Please fill in your details to create an account
        </p>
        <form onSubmit={handleRegister}>
          {/* <div className="mb-3">
            <label htmlFor="employee_id" className="form-label">Employee ID</label>
            <input
              type="text"
              id="employee_id"
              name="employee_id"
              required
              className="form-control"
              placeholder="Enter your employee ID"
              value={form.employee_id}
              onChange={handleChange}
            />
          </div> */}

          <div className="mb-3">
            <label htmlFor="employee_name" className="form-label">Full Name</label>
            <input
              type="text"
              id="employee_name"
              name="name"
              className="form-control"
              placeholder="Enter your full name"
              value={form.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="email" className="form-label">Email Address</label>
            <input
              type="email"
              id="email"
              name="email"
              required
              className="form-control"
              placeholder="Enter your email"
              value={form.email}
              onChange={handleChange}
            />
          </div>

          <div className="mb-3">
            <label htmlFor="phonenumber" className="form-label">Phone Number</label>
            <input
              type="tel"
              id="phonenumber"
              name="phonenumber"
              required
              className="form-control"
              placeholder="Enter your phone number"
              value={form.phonenumber}
              onChange={handleChange}
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Gender</label>
            <div>
              <div className="form-check form-check-inline">
                <input
                  type="radio"
                  name="gender"
                  value="Male"
                  className="form-check-input"
                  checked={form.gender === 'Male'}
                  onChange={handleChange}
                />
                <label className="form-check-label">Male</label>
              </div>
              <div className="form-check form-check-inline">
                <input
                  type="radio"
                  name="gender"
                  value="Female"
                  className="form-check-input"
                  checked={form.gender === 'Female'}
                  onChange={handleChange}
                />
                <label className="form-check-label">Female</label>
              </div>
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="noOfYearsExperience" className="form-label">Years of Experience</label>
            <input
              type="number"
              id="no_of_years_experience"
              name="noOfYearsExperience"
              min="0"
              required
              className="form-control"
              placeholder="Enter years of experience"
              value={form.noOfYearsExperience}
              onChange={handleChange}
            />
          </div>

          <div className="mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              required
              className="form-control"
              placeholder="Create a password"
              value={form.password}
              onChange={handleChange}
            />
          </div>

          <div className="mb-3">
            <label htmlFor="user_role" className="form-label">User Role</label>
            <select
              id="user_role"
              name="role"
              required
              className="form-select"
              value={form.role}
              onChange={handleChange}
            >
              <option value="">Select Role</option>
              <option value="EMPLOYEE">Employee</option>
              <option value="MANAGER">Manager</option>
              <option value="ADMIN">Admin</option>
            </select>
          </div>

          <div className="mb-4">
            <label htmlFor="job_designation" className="form-label">Job Designation</label>
            <input
              type="text"
              id="job_designation"
              name="jobDesignation"
              required
              className="form-control"
              placeholder="Enter your job designation"
              value={form.jobDesignation}
              onChange={handleChange}
            />
          </div>

          <div className="d-flex justify-content-between">
            <button type="submit" className="btn submit-button w-50 me-2" onClick={handleLoginRedirect}>
              Register
            </button>
            <button
              type="button"
              className="btn btn-outline-secondary w-50"
              onClick={handleLoginRedirect}
            >
              Already Registered? Login
            </button>
          </div>
        </form>
      </div>
    </div>
    </>
  );
}
