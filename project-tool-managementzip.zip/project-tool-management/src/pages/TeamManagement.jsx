import React, { useState, useEffect } from 'react';
import axios from '../api/dotnetaxios';

const TeamManager = () => {
  const [teams, setTeams] = useState([]);
  const [teamName, setTeamName] = useState('');
  const [selectedTeamId, setSelectedTeamId] = useState('');
  const [userId, setUserId] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  // Fetch teams
  useEffect(() => {
    const fetchTeams = async () => {
      try {
        const res = await axios.get('/teams');
        setTeams(Array.isArray(res.data) ? res.data : []);
      } catch (err) {
        console.error('Error fetching teams:', err);
      }
    };
    fetchTeams();
  }, []);

  const createTeam = async () => {
    if (!teamName.trim()) return setMessage('Team name is required');
    setLoading(true);
    try {
      const res = await axios.post('/teams', { name: teamName });
      setTeams(prev => [...prev, res.data]);
      setTeamName('');
      setMessage('Team created successfully!');
    // eslint-disable-next-line no-unused-vars
    } catch (error) {
      setMessage('Error creating team');
    } finally {
      setLoading(false);
    }
  };

  const addMember = async () => {
    if (!selectedTeamId || !userId) return setMessage('Team and UserId required');
    setLoading(true);
    try {
      await axios.post('/teams/add-member', {
        teamId: parseInt(selectedTeamId),
        userId: parseInt(userId)
      });
      setMessage('Member added successfully!');
      setUserId('');
      setSelectedTeamId('');
    // eslint-disable-next-line no-unused-vars
    } catch (err) {
      setMessage('Error adding member');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mt-4">
      <h2>Team Management</h2>

      {message && <div className="alert alert-info">{message}</div>}

      <div className="row">
        {/* Create Team */}
        <div className="col-md-6">
          <div className="card mb-4">
            <div className="card-body">
              <h5>Create Team</h5>
              <input
                type="text"
                className="form-control mb-2"
                placeholder="Team Name"
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
                disabled={loading}
              />
              <button className="btn btn-primary" onClick={createTeam} disabled={loading}>
                {loading ? 'Creating...' : 'Create Team'}
              </button>
            </div>
          </div>
        </div>

        {/* Add Member */}
        <div className="col-md-6">
          <div className="card mb-4">
            <div className="card-body">
              <h5>Add Member</h5>
              <select
                className="form-select mb-2"
                value={selectedTeamId}
                onChange={(e) => setSelectedTeamId(e.target.value)}
                disabled={loading}
              >
                <option value="">Select Team</option>
                {teams.map(team => (
                  <option key={team.id} value={team.id}>{team.name}</option>
                ))}
              </select>
              <input
                type="number"
                className="form-control mb-2"
                placeholder="User ID"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                disabled={loading}
              />
              <button className="btn btn-success" onClick={addMember} disabled={loading}>
                {loading ? 'Adding...' : 'Add Member'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Team List */}
      <div className="mt-4">
        <h4>Existing Teams</h4>
        <div className="row">
          {teams.map(team => (
            <div key={team.id} className="col-md-4 mb-3">
              <div className="card">
                <div className="card-body">
                  <h5>{team.name}</h5>
                  <p className="text-muted">Team ID: {team.id}</p>
                  <p>Members: {team.members?.length || 0}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TeamManager;
