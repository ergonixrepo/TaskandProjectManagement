import React, { useState, useEffect } from 'react';
import { FaPlay, FaPause, FaStop, FaRedo, FaHistory } from 'react-icons/fa';

const TimeTracker = ({ employeeId, onTimeTracked }) => {
  // State management
  const [isRunning, setIsRunning] = useState(false);
  const [startTime, setStartTime] = useState(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [sessions, setSessions] = useState([]);
  const [activeTask, setActiveTask] = useState(null);
  
  // Load saved data from localStorage
  useEffect(() => {
    const savedData = localStorage.getItem(`timeTracker_${employeeId}`);
    if (savedData) {
      const { sessions: savedSessions, activeTask: savedActiveTask } = JSON.parse(savedData);
      setSessions(savedSessions || []);
      if (savedActiveTask && savedActiveTask.isRunning) {
        setActiveTask(savedActiveTask);
        setElapsedTime(Math.floor((new Date() - new Date(savedActiveTask.startTime)) / 1000) * 1000);
        setIsRunning(true);
      }
    }
  }, [employeeId]);

  // Save data to localStorage
  useEffect(() => {
    const dataToSave = {
      sessions,
      activeTask: isRunning ? { ...activeTask, startTime } : null
    };
    localStorage.setItem(`timeTracker_${employeeId}`, JSON.stringify(dataToSave));
  }, [sessions, activeTask, isRunning, startTime, employeeId]);

  // Timer logic
  useEffect(() => {
    let interval;
    if (isRunning) {
      interval = setInterval(() => {
        setElapsedTime(prev => prev + 1000);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  // Format time for display
  const formatTime = (ms) => {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Control functions
  const handleStart = () => {
    if (!isRunning) {
      const taskName = prompt('Enter task name:');
      if (taskName) {
        const newTask = {
          id: Date.now(),
          name: taskName,
          startTime: new Date().toISOString()
        };
        setActiveTask(newTask);
        setStartTime(new Date());
        setIsRunning(true);
        setElapsedTime(0);
      }
    }
  };

  const handlePause = () => {
    if (isRunning) {
      setIsRunning(false);
      const newSession = {
        taskId: activeTask.id,
        taskName: activeTask.name,
        start: startTime,
        end: new Date(),
        duration: elapsedTime
      };
      setSessions(prev => [...prev, newSession]);
    }
  };

  const handleStop = () => {
    if (isRunning || elapsedTime > 0) {
      const endTime = new Date();
      const newSession = {
        taskId: activeTask.id,
        taskName: activeTask.name,
        start: startTime,
        end: endTime,
        duration: elapsedTime
      };
      
      setSessions(prev => [...prev, newSession]);
      onTimeTracked && onTimeTracked(activeTask.id, formatTime(elapsedTime), elapsedTime);
      
      // Reset timer
      setIsRunning(false);
      setElapsedTime(0);
      setStartTime(null);
      setActiveTask(null);
    }
  };

  const handleReset = () => {
    setIsRunning(false);
    setElapsedTime(0);
    setStartTime(null);
    setActiveTask(null);
  };

  const clearHistory = () => {
    if (window.confirm('Are you sure you want to clear all history?')) {
      setSessions([]);
    }
  };

  return (
    <div className="container mt-4">
      <div className="card shadow-sm">
        <div className="card-body">
          <h3 className="card-title mb-4">Time Tracker</h3>
          
          {activeTask && (
            <div className="alert alert-info mb-3">
              <strong>Current Task:</strong> {activeTask.name}
            </div>
          )}

          <div className="timer-display text-center mb-4">
            <h1 className="display-4">{formatTime(elapsedTime)}</h1>
          </div>
          
          <div className="timer-controls d-flex justify-content-center mb-4">
            {!isRunning ? (
              <button 
                onClick={handleStart} 
                className="btn btn-success me-2"
              >
                <FaPlay className="me-1" /> Start New Task
              </button>
            ) : (
              <button 
                onClick={handlePause} 
                className="btn btn-warning me-2"
              >
                <FaPause className="me-1" /> Pause
              </button>
            )}
            
            <button 
              onClick={handleStop} 
              className="btn btn-danger me-2"
              disabled={!isRunning && elapsedTime === 0}
            >
              <FaStop className="me-1" /> Stop & Save
            </button>
            
            <button 
              onClick={handleReset} 
              className="btn btn-secondary"
              disabled={elapsedTime === 0}
            >
              <FaRedo className="me-1" /> Reset
            </button>
          </div>

          {sessions.length > 0 && (
            <div className="session-history mt-4">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <h4><FaHistory className="me-2" />Session History</h4>
                <button 
                  onClick={clearHistory} 
                  className="btn btn-sm btn-outline-danger"
                >
                  Clear History
                </button>
              </div>
              <div className="table-responsive">
                <table className="table table-hover">
                  <thead>
                    <tr>
                      <th>Task</th>
                      <th>Start Time</th>
                      <th>End Time</th>
                      <th>Duration</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sessions.map((session, index) => (
                      <tr key={index}>
                        <td>{session.taskName}</td>
                        <td>{new Date(session.start).toLocaleString()}</td>
                        <td>{new Date(session.end).toLocaleString()}</td>
                        <td>{formatTime(session.duration)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TimeTracker;