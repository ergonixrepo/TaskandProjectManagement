import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/indexs.css'; 
import Navbar from '../components/Navbar';
import heroImage from '../assets/bannarinnerImg.png';
import { FaArrowRight } from 'react-icons/fa';
import Footer from '../components/Footers';
const Index = () => {
  const navigate = useNavigate();

  return (
    <>
      {/* Navbar */}
      <Navbar />

      {/* Hero Section */}
      <div className="hero-section">
        <div className="hero-text">
          <div className="subtitle">Streamline Projects Teams and Tools in One Place</div>
          <h2> Plan tasks, manage resources, track progress, and boost team productivity with an all-in-one workplace management system.</h2>
          <p className="description">
          Perfect for startups, agencies, and growing teams who need clarity, accountability, and smooth collaboration.
          </p>
          <div className="hero-buttons">
            <button className="btn btn-danger me-3 d-flex align-items-center" onClick={() => navigate('/choose-role')}>
              Get Started <FaArrowRight className="ms-2" />
            </button>
          </div>
        </div>

        <div className="hero-image">
          <img src={heroImage} alt="Hero" className="img-fluid" />
        </div>
      </div>

      {/* Info Section with Video */}
      <section className="info-section d-flex flex-column flex-md-row align-items-center justify-content-center px-4 py-5">
        <div className="info-media mb-4 mb-md-0 me-md-5">
          <video
            src="/workload-video.mp4"
            className="img-fluid rounded shadow"
            style={{ maxWidth: '500px' }}
            autoPlay
            muted
            loop
            playsInline
          />
        </div>
          <div className="info-text text-start">
          <h4 className="text-primary fw-semibold mb-2">
            Plans change. Resource management stays on point.
          </h4>
          <p className="mb-4 text-muted" style={{ maxWidth: '500px' }}>
            Clients wanting things yesterday? A massive job on the horizon? Key Account Manager suddenly resigned?
            Be ready for any resourcing challenge.
          </p>
          <ul className="list-unstyled mb-4 text-muted">
            <li className="mb-2">✔ See staff availability & workloads at a glance</li>
            <li className="mb-2">✔ Forecast and manage resources without guesswork</li>
            <li>✔ Easily check if you’re under or over-utilizing your team</li>
          </ul>
           <button className="btn btn-danger me-3 d-flex align-items-center" onClick={() => navigate('/choose-role')}>
              Get Started <FaArrowRight className="ms-2" />
            </button>
        </div>
      </section>
       <section className="info-section d-flex flex-column flex-md-row align-items-center justify-content-center px-4 py-5">
        <div className="info-media mb-4 mb-md-0 me-md-5">
          <video
            src="/Timing.mp4"
            className="img-fluid rounded shadow"
            style={{ maxWidth: '500px' }}
            autoPlay
            muted
            loop
            playsInline
          />
        </div>
          <div className="info-text text-start">
          <h4 className="text-primary fw-semibold mb-2">
            Keep Your Team Balanced and Productive
          </h4>
          <p className="mb-4 text-muted" style={{ maxWidth: '500px' }}>
           Ensure tasks are completed without overworking your team.
          </p>
          <ul className="list-unstyled mb-4 text-muted">
            <li className="mb-2">✔ See how well your team’s time and skills are used in real time.</li>
            <li className="mb-2">✔ Spot gaps and overloads early to keep everyone on track.</li>
            <li>✔ Get a clear view of who is available and who needs support</li>
          </ul>
           <button className="btn btn-danger me-3 d-flex align-items-center" onClick={() => navigate('/choose-role')}>
              Get Started <FaArrowRight className="ms-2" />
            </button>
        </div>
      </section>
      {/* footer */}
     <Footer />
    </>
  );
};

export default Index;
