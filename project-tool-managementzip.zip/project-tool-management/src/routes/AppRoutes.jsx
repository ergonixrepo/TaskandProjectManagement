import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from '../pages/Login';
import Register from '../pages/Register';
import ManagerDashboard from '../pages/ManagerDashboard';
import EmployeeDashboard from '../pages/EmployeeDashboard';
import ProtectedRoute from './ProtectedRoute';
import NotFound from '../pages/NotFound';
import Contact from '../pages/Contact';
import ChooseRole from "../pages/ChooseRole";
import About from "../pages/About";
import AssignTasks from '../pages/AssignTasks';
import RedirectBasedOnRole from '../components/RedirectBasedOnRole';
import NavBar from "../components/Navbar";
import Footer from "../components/Footers";
import Index from '../pages/index';
import AdminDashboard from '../pages/AdminDashboard';
function App() {
  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/manager-dashboard" element={
        <ProtectedRoute allowedRole="manager">
          <ManagerDashboard />
        </ProtectedRoute>
      } />
      <Route path="/assign-task" element={
        <ProtectedRoute allowedRole="manager">
          <AssignTasks />
        </ProtectedRoute>
      } />
      <Route path="/employee-dashboard" element={
        <ProtectedRoute allowedRole="employee">
          <EmployeeDashboard />
        </ProtectedRoute>
      } />
      <Route path="/admin-dashboard" element={
        <ProtectedRoute allowedRole="admin">
          <AdminDashboard />
        </ProtectedRoute>
      } />
      <Route path="/footer" element={<Footer />} />
      <Route path="/navbar" element={<NavBar />} />
      <Route path="/choose-role" element={<ChooseRole />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/about" element={<About />} />

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
