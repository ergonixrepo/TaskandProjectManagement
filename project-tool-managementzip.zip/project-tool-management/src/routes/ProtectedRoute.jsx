import React from 'react';
import { Navigate } from 'react-router-dom';

export default function ProtectedRoute({ children, allowedRole }) {
  const token = localStorage.getItem('token');
  const storedRole = localStorage.getItem('role'); // 👈 We’ll store this in Login

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // ✅ If you passed `allowedRole` — check it!
  if (allowedRole && storedRole !== allowedRole) {
    console.warn(`Blocked: Required=${allowedRole} but got ${storedRole}`);
    return <Navigate to="/login" replace />;
  }

  return children;
}
